// Mock data for Hyderabad Hardware website

export const companyInfo = {
  name: "Hyderabad Hardware",
  tagline: "Premium Interior Solutions Since Decades",
  address: {
    line1: "Sai Avenue, 198 & 199, Kamalapuri Colony",
    line2: "Srinagar Colony Main Road",
    line3: "Srinagar Colony – 500073",
    city: "Hyderabad",
    state: "Telangana",
    country: "India"
  },
  phones: ["9849244555", "9676748323"],
  emails: ["hydexcl@gmail.com", "ikanodia2004@gmail.com"],
  logoUrl: "https://customer-assets.emergentagent.com/job_hyd-hardware/artifacts/jqhfjvjx_ChatGPT%20Image%20Jan%201%2C%202026%2C%2001_48_22%20PM.png"
};

export const experienceCentres = [
  {
    id: "blum",
    name: "Blum Experience Centre",
    tagline: "Experience Centre by Hyderabad Hardware",
    description: "Blum is a global leader in furniture fittings & motion technologies from Austria. Known for functionality, durability, and user comfort.",
    logo: "https://customer-assets.emergentagent.com/job_hyd-hardware/artifacts/ykm9f8ed_Screenshot%202026-01-22%20at%2012.23.08%E2%80%AFAM.png",
    website: "https://www.blum.com/in/en/",
    color: "#F7941D"
  },
  {
    id: "astronea",
    name: "Astronea Experience Centre",
    tagline: "Italian Wardrobe Concept by Hyderabad Hardware",
    description: "Design-driven, modular interior systems from Italy. Focus on wardrobes, doors, and architectural interiors.",
    logo: "https://customer-assets.emergentagent.com/job_hyd-hardware/artifacts/kdibjj5c_Screenshot%202026-01-22%20at%2012.25.21%E2%80%AFAM.png",
    website: "https://www.astronea.in/",
    color: "#8BC34A"
  }
];

export const brandLogos = {
  hyderabadHardware: "https://customer-assets.emergentagent.com/job_hyd-hardware/artifacts/jqhfjvjx_ChatGPT%20Image%20Jan%201%2C%202026%2C%2001_48_22%20PM.png",
  blum: "https://customer-assets.emergentagent.com/job_hyd-hardware/artifacts/ykm9f8ed_Screenshot%202026-01-22%20at%2012.23.08%E2%80%AFAM.png",
  astronea: "https://customer-assets.emergentagent.com/job_hyd-hardware/artifacts/kdibjj5c_Screenshot%202026-01-22%20at%2012.25.21%E2%80%AFAM.png",
  salice: "https://customer-assets.emergentagent.com/job_hyd-hardware/artifacts/gusfzs8q_Screenshot%202026-01-22%20at%2012.19.31%E2%80%AFAM.png",
  dorset: "https://customer-assets.emergentagent.com/job_hyd-hardware/artifacts/w3sj2rzu_Screenshot%202026-01-22%20at%2012.19.36%E2%80%AFAM.png",
  hettich: "https://customer-assets.emergentagent.com/job_hyd-hardware/artifacts/zmkq6hhx_Screenshot%202026-01-22%20at%2012.20.17%E2%80%AFAM.png",
  grass: "https://customer-assets.emergentagent.com/job_hyd-hardware/artifacts/1agxgn52_Screenshot%202026-01-22%20at%2012.23.22%E2%80%AFAM.png",
  labacha: "https://customer-assets.emergentagent.com/job_hyd-hardware/artifacts/3ezyv5wk_Screenshot%202026-01-22%20at%2012.22.30%E2%80%AFAM.png"
};

export const blumProducts = [
  {
    id: 1,
    category: "Lift Systems",
    name: "AVENTOS Lift Systems",
    description: "Masterfully staged wall cabinets with next-gen lift systems that elevate living spaces with convenience and style.",
    image: "https://www.blum.com/images/600/400/4053381/localmedia/in/homepage/aventos-top-(1)_3:2.jpg",
    features: ["Soft-close technology", "Multiple opening angles", "Effortless operation"]
  },
  {
    id: 2,
    category: "Runner Systems",
    name: "TANDEM Runners",
    description: "Feather-light glide, integrated soft-close, 30 kg load capacity, multiple nominal lengths, and optional motion technologies.",
    image: "https://www.blum.com/images/600/400/4053357/localmedia/in/homepage/tandem-runner_3:2-2.jpg",
    features: ["100,000 cycle tested", "30kg load capacity", "Integrated soft-close"]
  },
  {
    id: 3,
    category: "Box Systems",
    name: "LEGRABOX",
    description: "Bring inspiring drawer designs to life with LEGRABOX. The slimmest drawer sides and stunning design possibilities.",
    image: "https://www.blum.com/images/600/400/4173680/corporate/media/bilder/produkte/boxsysteme/legrabox-design/me18652786_aa_fot_fo_bau_-sall_-amc_-v1_3:2.jpg",
    features: ["Slimmest drawer sides", "Premium design", "Smooth glide"]
  },
  {
    id: 4,
    category: "Pocket Systems",
    name: "REVEGO",
    description: "Expand your design freedom. REVEGO opens up a multitude of possibilities for flexible and multifunctional use of space.",
    image: "https://www.blum.com/images/600/400/4179638/corporate/media/bilder/produkte/pocketsysteme/blum_revego_me-25342742_3:2.jpg",
    features: ["Space optimization", "Flexible design", "Multifunctional"]
  },
  {
    id: 5,
    category: "Hinge Systems",
    name: "CLIP top BLUMOTION",
    description: "Our wide range of hinges offer the right solution for any furniture project with integrated soft-close.",
    image: "https://www.blum.com/images/235/177/4180375/corporate/media/bilder/produkte/scharniersysteme/overview/me9974430_4:3.jpg",
    features: ["Soft-close integrated", "Tool-free adjustment", "Wide opening angle"]
  },
  {
    id: 6,
    category: "Motion Technologies",
    name: "BLUMOTION & SERVO-DRIVE",
    description: "Each of our four motion technologies can be used individually and each has its own special strengths.",
    image: "https://www.blum.com/images/235/177/4180381/corporate/media/bilder/produkte/bewegungstechnologien/4-fuer-mehr/img2600_aa_fot_fo_bau_-sall_-am_-v2_4:3.jpg",
    features: ["Soft-close", "Push-to-open", "Electric opening"]
  }
];

export const astroneaProducts = [
  {
    id: 1,
    category: "Openable Wardrobes",
    name: "Openable Wardrobe Systems",
    description: "Premium openable wardrobe solutions with Italian design aesthetics and superior functionality.",
    image: "https://www.astronea.in/assets/images/services/openable.jpg",
    series: ["Continental", "Houston", "Venice", "Greek", "Vesta"]
  },
  {
    id: 2,
    category: "Sliding Wardrobes",
    name: "Sliding Wardrobe Systems",
    description: "Space-efficient sliding wardrobes with smooth operation and contemporary designs.",
    image: "https://www.astronea.in/assets/images/services/sliding.jpg",
    series: ["Topline Chester Pro", "Emirates", "Lufthansa", "Etihad"]
  },
  {
    id: 3,
    category: "Walk-in Wardrobes",
    name: "Full Glass & Walk-In Wardrobes",
    description: "Luxury walk-in wardrobe solutions with full glass options and open walk-in configurations.",
    image: "https://www.astronea.in/assets/images/services/wardrobe.jpg",
    series: ["Phoenix", "Pinnacle", "Malta", "Kay", "Axe"]
  },
  {
    id: 4,
    category: "Door Systems",
    name: "Universal Swing Doors",
    description: "Premium swing door systems with hydraulic pivot options and elegant frame designs.",
    image: "https://www.astronea.in/assets/images/services/universal.jpg",
    series: ["Cyprus", "Jordon", "Boston", "Lisbon Pivot"]
  },
  {
    id: 5,
    category: "Partition Systems",
    name: "Partition Doors",
    description: "Elegant partition door solutions for space division with style and functionality.",
    image: "https://www.astronea.in/assets/images/services/partition.jpg",
    series: ["PT Door", "Cyprus", "Cathey Telescopic", "Delta"]
  },
  {
    id: 6,
    category: "Sliding Folding",
    name: "Sliding Folding Systems",
    description: "Innovative sliding-folding door systems for flexible space management.",
    image: "https://www.astronea.in/assets/images/services/sliding1.jpg",
    series: ["Dragon", "Cathey", "Cyprus"]
  },
  {
    id: 7,
    category: "Premium Doors",
    name: "Premium Door Systems",
    description: "High-end door solutions including flush doors and architectural door systems.",
    image: "https://www.astronea.in/assets/images/services/premium.jpg",
    series: ["Zurich Flush", "Swiss Flush", "Dublin", "Burlin"]
  },
  {
    id: 8,
    category: "Shower Enclosures",
    name: "Premium Shower Enclosures",
    description: "Luxury shower enclosure systems with swing and sliding options.",
    image: "https://www.astronea.in/assets/images/services/shower.jpg",
    series: ["Boston", "Texas", "Delta Swing", "Luxor Sliding"]
  }
];

export const hardwareProducts = [
  {
    id: 1,
    category: "Furniture & Cabinet Hardware",
    name: "Cabinet Handles & Pulls",
    description: "Premium cabinet handles in various finishes including brass, chrome, and antique designs.",
    applications: ["Kitchens", "Wardrobes", "Furniture", "Commercial interiors"]
  },
  {
    id: 2,
    category: "Furniture & Cabinet Hardware",
    name: "Hinges & Channels",
    description: "High-quality hinges and channel systems for smooth furniture operation.",
    applications: ["Cabinet doors", "Wardrobe doors", "Furniture"]
  },
  {
    id: 3,
    category: "Furniture & Cabinet Hardware",
    name: "Drawer Systems",
    description: "Tandem box and drawer systems for superior drawer functionality.",
    applications: ["Kitchen drawers", "Wardrobe drawers", "Office furniture"]
  },
  {
    id: 4,
    category: "Door Hardware & Locking",
    name: "Main Door Handles",
    description: "Elegant main door handles in premium finishes for residential and commercial entrances.",
    applications: ["Main entrances", "Office doors", "Hotel rooms"]
  },
  {
    id: 5,
    category: "Door Hardware & Locking",
    name: "Mortise Handles & Lock Bodies",
    description: "Complete mortise handle sets with high-security lock bodies.",
    applications: ["Residential doors", "Commercial spaces", "Security doors"]
  },
  {
    id: 6,
    category: "Door Hardware & Locking",
    name: "Cylinders & Door Closers",
    description: "Security cylinders and smooth-operating door closers for all applications.",
    applications: ["All door types", "Fire doors", "Automatic doors"]
  }
];

export const brands = [
  {
    id: 1,
    name: "Salice",
    origin: "Italy",
    specialty: "Furniture hinges & fittings",
    description: "World-renowned Italian manufacturer of furniture hinges, drawer systems, and lifting mechanisms.",
    logo: "https://customer-assets.emergentagent.com/job_hyd-hardware/artifacts/gusfzs8q_Screenshot%202026-01-22%20at%2012.19.31%E2%80%AFAM.png"
  },
  {
    id: 2,
    name: "Dorset",
    origin: "India",
    specialty: "Door handles, locks, cylinders",
    description: "Leading manufacturer of architectural hardware including handles, locks, and security solutions.",
    logo: "https://customer-assets.emergentagent.com/job_hyd-hardware/artifacts/w3sj2rzu_Screenshot%202026-01-22%20at%2012.19.36%E2%80%AFAM.png"
  },
  {
    id: 3,
    name: "Hettich",
    origin: "Germany",
    specialty: "Hinges, drawer systems, channels",
    description: "German precision engineering in furniture fittings, drawer systems, and sliding door hardware.",
    logo: "https://customer-assets.emergentagent.com/job_hyd-hardware/artifacts/zmkq6hhx_Screenshot%202026-01-22%20at%2012.20.17%E2%80%AFAM.png"
  },
  {
    id: 4,
    name: "Grass",
    origin: "Austria",
    specialty: "Tandem box & drawer systems",
    description: "Austrian innovation in drawer systems, hinges, and movement systems for furniture.",
    logo: "https://customer-assets.emergentagent.com/job_hyd-hardware/artifacts/1agxgn52_Screenshot%202026-01-22%20at%2012.23.22%E2%80%AFAM.png"
  },
  {
    id: 5,
    name: "Labacha",
    origin: "India",
    specialty: "Architectural & cabinet handles",
    description: "Premium architectural hardware specializing in designer handles and cabinet fittings.",
    logo: "https://customer-assets.emergentagent.com/job_hyd-hardware/artifacts/3ezyv5wk_Screenshot%202026-01-22%20at%2012.22.30%E2%80%AFAM.png"
  }
];

export const showroomZones = [
  {
    id: 1,
    name: "Hyderabad Hardware",
    floor: "Ground Floor",
    description: "Main hardware store featuring complete range of furniture fittings, door hardware, and cabinet solutions.",
    highlights: ["Cabinet hardware", "Door locks & handles", "Drawer systems", "Hinges & channels"]
  },
  {
    id: 2,
    name: "Blum Experience Centre",
    floor: "First Floor",
    description: "Dedicated Blum showcase featuring Austrian motion technologies, lift systems, and drawer innovations.",
    highlights: ["AVENTOS lift systems", "LEGRABOX drawers", "Motion technologies", "Live demonstrations"]
  },
  {
    id: 3,
    name: "Astronea Experience Centre",
    floor: "Second Floor",
    description: "Italian wardrobe concept showroom displaying modular wardrobes, doors, and interior systems.",
    highlights: ["Walk-in wardrobes", "Sliding systems", "Glass wardrobes", "Door systems"]
  }
];

export const testimonials = [
  {
    id: 1,
    name: "Rajesh Kumar",
    role: "Interior Designer",
    company: "Kumar Interiors",
    quote: "Hyderabad Hardware has been our go-to partner for premium hardware solutions. Their Blum and Astronea experience centres are a designer's dream.",
    rating: 5
  },
  {
    id: 2,
    name: "Priya Sharma",
    role: "Architect",
    company: "Sharma & Associates",
    quote: "The quality of products and technical expertise at Hyderabad Hardware is unmatched. They truly understand architectural hardware.",
    rating: 5
  },
  {
    id: 3,
    name: "Mohammed Ali",
    role: "Contractor",
    company: "Ali Constructions",
    quote: "Reliable, premium quality, and excellent service. We've completed over 50 projects with hardware from Hyderabad Hardware.",
    rating: 5
  }
];

export const stats = [
  { label: "Years of Excellence", value: "25+" },
  { label: "Projects Completed", value: "10,000+" },
  { label: "Happy Clients", value: "5,000+" },
  { label: "Premium Brands", value: "15+" }
];
