import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Check, ExternalLink, Phone } from 'lucide-react';
import { Button } from '../components/ui/button';
import { astroneaProducts, companyInfo, brandLogos } from '../data/mock';

const AstronePage = () => {
  const astroneaSolutions = [
    {
      id: 1,
      category: 'Wardrobe Systems',
      name: 'Openable Wardrobes',
      description: 'Premium openable wardrobe solutions with Italian design aesthetics and superior functionality.',
      image: 'https://www.astronea.in/assets/images/services/openable.jpg',
      series: ['Continental', 'Houston', 'Venice', 'Greek', 'Vesta', 'Munich', 'Bristol'],
      features: ['Italian design', 'Multiple series', 'Custom sizes', 'Premium finishes']
    },
    {
      id: 2,
      category: 'Wardrobe Systems',
      name: 'Sliding Wardrobes',
      description: 'Space-efficient sliding wardrobe systems with smooth operation and contemporary designs.',
      image: 'https://www.astronea.in/assets/images/services/sliding.jpg',
      series: ['Topline Chester Pro', 'Emirates', 'Lufthansa', 'Etihad', 'Frontier', 'Garuda'],
      features: ['Space efficient', 'Smooth glide', 'Modern design', 'Various finishes']
    },
    {
      id: 3,
      category: 'Wardrobe Systems',
      name: 'Walk-in & Glass Wardrobes',
      description: 'Luxury walk-in wardrobe solutions with full glass options and open configurations.',
      image: 'https://www.astronea.in/assets/images/services/wardrobe.jpg',
      series: ['Phoenix', 'Pinnacle', 'Malta', 'Kay', 'Axe', 'Way', 'Zed'],
      features: ['Full glass options', 'Walk-in designs', 'LED integration', 'Modular']
    },
    {
      id: 4,
      category: 'Door Systems',
      name: 'Universal Swing Doors',
      description: 'Premium swing door systems with hydraulic pivot options and elegant frame designs.',
      image: 'https://www.astronea.in/assets/images/services/universal.jpg',
      series: ['Cyprus', 'Jordon', 'Jackson', 'Boston', 'Plano', 'Navona', 'Delta'],
      features: ['Hydraulic pivot', 'Elegant frames', 'Multiple sizes', 'Premium glass']
    },
    {
      id: 5,
      category: 'Door Systems',
      name: 'Partition Doors',
      description: 'Elegant partition door solutions for space division with style and functionality.',
      image: 'https://www.astronea.in/assets/images/services/partition.jpg',
      series: ['PT Door', 'Cyprus', 'Cathey Telescopic', 'Dragon', 'Delta Pro'],
      features: ['Space division', 'Sound reduction', 'Light filtering', 'Modern aesthetic']
    },
    {
      id: 6,
      category: 'Door Systems',
      name: 'Sliding Folding Systems',
      description: 'Innovative sliding-folding door systems for flexible space management.',
      image: 'https://www.astronea.in/assets/images/services/sliding1.jpg',
      series: ['Dragon', 'Cathey', 'Cyprus', 'Hemus', 'Hemus Pro'],
      features: ['Flexible opening', 'Space saving', 'Multiple panels', 'Smooth operation']
    },
    {
      id: 7,
      category: 'Premium Systems',
      name: 'Aluminium & Decorative Units',
      description: 'Premium aluminium structures for walk-in wardrobes and decorative display units.',
      image: 'https://www.astronea.in/assets/images/services/aluminium.jpg',
      series: ['Crockery Series', 'Alu Carcass', 'Arial Shelving'],
      features: ['Aluminium frames', 'Glass options', 'LED ready', 'Custom sizes']
    },
    {
      id: 8,
      category: 'Premium Systems',
      name: 'Shower Enclosures',
      description: 'Luxury shower enclosure systems with swing and sliding options.',
      image: 'https://www.astronea.in/assets/images/services/shower.jpg',
      series: ['Boston', 'Texas', 'Delta Swing', 'Luxor Sliding', 'Ural Curve'],
      features: ['Premium glass', 'Multiple configs', 'Easy clean', 'Elegant hardware']
    }
  ];

  return (
    <div className="bg-[#0a0a0a]">
      {/* Hero Section */}
      <section className="relative py-32 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1200&auto=format&fit=crop&q=60"
            alt="Astronea Wardrobe"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a] via-[#0a0a0a]/95 to-[#0a0a0a]/70" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-[#0a0a0a]/50" />
        </div>
        <div className="absolute inset-0 opacity-[0.02]" style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, #8BC34A 1px, transparent 0)`,
          backgroundSize: '50px 50px'
        }} />
        
        <div className="container-custom relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="mb-8">
                <img 
                  src={brandLogos.astronea} 
                  alt="Astronea Logo" 
                  className="h-14 w-auto object-contain mb-4"
                />
                <span className="text-[#8BC34A] text-sm font-semibold tracking-[0.2em] uppercase">Experience Centre by Hyderabad Hardware</span>
              </div>
              
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Italian <span className="text-[#8BC34A]">Wardrobe Concept</span>
              </h2>
              
              <p className="text-white/70 text-lg mb-8">
                Astronea brings Italian design excellence to wardrobes, doors, and interior systems. With innovative modular solutions, Astronea transforms living spaces with style, functionality, and craftsmanship.
              </p>
              
              <div className="flex flex-wrap gap-4 mb-8">
                <a href={`tel:${companyInfo.phones[0]}`}>
                  <Button size="lg" className="bg-[#8BC34A] hover:bg-[#7cb342] text-white font-semibold px-8">
                    <Phone size={18} className="mr-2" />
                    Schedule Visit
                  </Button>
                </a>
                <a href="https://www.astronea.in/" target="_blank" rel="noopener noreferrer">
                  <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 px-8">
                    <ExternalLink size={18} className="mr-2" />
                    Official Website
                  </Button>
                </a>
              </div>
              
              <div className="flex items-center gap-6 text-sm text-white/60">
                <span className="flex items-center gap-2">
                  <Check size={16} className="text-[#8BC34A]" /> Italian Design
                </span>
                <span className="flex items-center gap-2">
                  <Check size={16} className="text-[#8BC34A]" /> Modular Systems
                </span>
              </div>
            </div>
            
            <div className="relative hidden lg:block">
              <img
                src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&auto=format&fit=crop&q=60"
                alt="Astronea Wardrobe"
                className="rounded-xl shadow-2xl w-full h-[500px] object-cover"
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-lg shadow-xl">
                <p className="text-xs text-gray-500 mb-1">Located at</p>
                <p className="font-semibold text-[#1a1a1a]">Second Floor</p>
                <p className="text-sm text-gray-600">Hyderabad Hardware Building</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Astronea */}
      <section className="py-20 bg-white">
        <div className="container-custom">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="text-[#8BC34A] text-sm font-semibold tracking-wider uppercase">About Astronea</span>
              <h2 className="text-3xl md:text-4xl font-bold text-[#1a1a1a] mt-4 mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Design Excellence from Italy
              </h2>
              <div className="space-y-4 text-gray-600">
                <p>
                  In a world where new-age design is welcome, Astronea takes it a step further in the world of wardrobes and doors with its unique modular systems. The designs that stand out, the functionality that emanates brilliance, the quality that sets benchmarks.
                </p>
                <p>
                  Astronea offers comprehensive interior solutions including openable wardrobes, sliding wardrobes, walk-in wardrobes, full glass wardrobes, door systems, partition solutions, and premium shower enclosures.
                </p>
                <p>
                  At our Astronea Experience Centre, explore the complete range of Italian-inspired interior systems. Our specialists will guide you through design options, finishes, and configurations tailored to your space.
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <img
                src="https://www.astronea.in/assets/images/services/openable.jpg"
                alt="Openable Wardrobe"
                className="rounded-xl shadow-lg"
              />
              <img
                src="https://www.astronea.in/assets/images/services/sliding.jpg"
                alt="Sliding Wardrobe"
                className="rounded-xl shadow-lg mt-8"
              />
              <img
                src="https://www.astronea.in/assets/images/services/universal.jpg"
                alt="Swing Door"
                className="rounded-xl shadow-lg"
              />
              <img
                src="https://www.astronea.in/assets/images/services/partition.jpg"
                alt="Partition Door"
                className="rounded-xl shadow-lg mt-8"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Product Categories */}
      <section className="py-20 bg-[#f5f5f5]">
        <div className="container-custom">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-[#8BC34A] text-sm font-semibold tracking-wider uppercase">Astronea Collections</span>
            <h2 className="text-3xl md:text-4xl font-bold text-[#1a1a1a] mt-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Solutions Available at Our Centre
            </h2>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {astroneaSolutions.map((solution) => (
              <div key={solution.id} className="bg-white rounded-xl overflow-hidden premium-card group">
                <div className="relative h-40 overflow-hidden">
                  <img
                    src={solution.image}
                    alt={solution.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute top-3 left-3">
                    <span className="px-2 py-1 bg-[#8BC34A] text-white text-xs font-medium rounded-full">
                      {solution.category}
                    </span>
                  </div>
                </div>
                <div className="p-5">
                  <h3 className="text-lg font-bold text-[#1a1a1a] mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
                    {solution.name}
                  </h3>
                  <p className="text-gray-600 text-sm mb-3 line-clamp-2">{solution.description}</p>
                  
                  <div className="mb-3">
                    <div className="flex flex-wrap gap-1">
                      {solution.series.slice(0, 3).map((series, idx) => (
                        <span key={idx} className="px-2 py-0.5 bg-[#f5f5f5] text-gray-600 rounded text-xs">
                          {series}
                        </span>
                      ))}
                      {solution.series.length > 3 && (
                        <span className="px-2 py-0.5 bg-[#8BC34A]/10 text-[#8BC34A] rounded text-xs">
                          +{solution.series.length - 3} more
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Wardrobe Types Showcase */}
      <section className="py-20 bg-[#1a1a1a]">
        <div className="container-custom">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-[#8BC34A] text-sm font-semibold tracking-wider uppercase">Wardrobe Solutions</span>
            <h2 className="text-3xl md:text-4xl font-bold text-white mt-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Complete Wardrobe Systems
            </h2>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { name: 'Openable', desc: 'Classic hinged door wardrobes with multiple series' },
              { name: 'Sliding', desc: 'Space-efficient sliding wardrobe systems' },
              { name: 'Walk-in', desc: 'Luxury open walk-in configurations' },
              { name: 'Full Glass', desc: 'Premium glass wardrobe solutions' }
            ].map((type, idx) => (
              <div key={idx} className="bg-[#252525] p-6 rounded-xl text-center">
                <div className="w-14 h-14 bg-[#8BC34A]/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-xl font-bold text-[#8BC34A]">{type.name.charAt(0)}</span>
                </div>
                <h4 className="font-semibold text-white mb-2">{type.name} Wardrobes</h4>
                <p className="text-white/60 text-sm">{type.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Door Systems Highlight */}
      <section className="py-20 bg-white">
        <div className="container-custom">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <img
                src="https://www.astronea.in/assets/images/services/universal.jpg"
                alt="Door Systems"
                className="rounded-xl shadow-xl"
              />
            </div>
            
            <div className="order-1 lg:order-2">
              <span className="text-[#8BC34A] text-sm font-semibold tracking-wider uppercase">Door & Partition Systems</span>
              <h2 className="text-3xl md:text-4xl font-bold text-[#1a1a1a] mt-4 mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Complete Door Solutions
              </h2>
              <p className="text-gray-600 mb-6">
                Astronea offers comprehensive door systems including swing doors, sliding doors, partition doors, and sliding-folding mechanisms. Each system is designed for smooth operation, elegant aesthetics, and lasting durability.
              </p>
              
              <div className="space-y-4">
                {[
                  { name: 'Swing Doors', desc: 'Hydraulic pivot and standard swing options' },
                  { name: 'Sliding Doors', desc: 'Smooth gliding partition and room dividers' },
                  { name: 'Sliding-Folding', desc: 'Flexible space management solutions' },
                  { name: 'Premium Doors', desc: 'Flush doors with architectural finish' }
                ].map((door, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <Check className="text-[#8BC34A] mt-0.5" size={18} />
                    <div>
                      <h4 className="font-semibold text-[#1a1a1a]">{door.name}</h4>
                      <p className="text-gray-600 text-sm">{door.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-[#8BC34A] to-[#7cb342]">
        <div className="container-custom text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Experience Astronea at Our Centre
          </h2>
          <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">
            Visit our Astronea Experience Centre to explore the complete range of Italian wardrobe and door solutions. Let our experts help you design your perfect space.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/contact">
              <Button size="lg" className="bg-white text-[#8BC34A] hover:bg-white/90 font-semibold px-8">
                Visit Showroom <ArrowRight size={18} className="ml-2" />
              </Button>
            </Link>
            <a href={`tel:${companyInfo.phones[0]}`}>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10 px-8">
                <Phone size={18} className="mr-2" />
                {companyInfo.phones[0]}
              </Button>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AstronePage;
