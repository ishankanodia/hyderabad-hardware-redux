import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Globe, Award } from 'lucide-react';
import { Button } from '../components/ui/button';
import { brands, brandLogos } from '../data/mock';

const BrandsPage = () => {
  const detailedBrands = [
    {
      id: 1,
      name: 'Salice',
      origin: 'Italy',
      logo: brandLogos.salice,
      specialty: 'Furniture Hinges & Fittings',
      description: 'Salice is a world-renowned Italian manufacturer of furniture hinges, drawer systems, and lifting mechanisms. With over 60 years of experience, Salice combines Italian design excellence with innovative engineering to create fittings that offer superior functionality and aesthetics.',
      products: ['Concealed hinges', 'Soft-close mechanisms', 'Drawer systems', 'Lift systems', 'Push-open systems']
    },
    {
      id: 2,
      name: 'Dorset',
      origin: 'India',
      logo: brandLogos.dorset,
      specialty: 'Door Handles, Locks, Cylinders',
      description: 'Dorset is a leading Indian manufacturer of architectural hardware, offering a comprehensive range of door handles, locks, and security solutions. Known for quality and innovation, Dorset combines contemporary design with reliable performance.',
      products: ['Door handles', 'Mortise locks', 'Security cylinders', 'Door closers', 'Padlocks']
    },
    {
      id: 3,
      name: 'Hettich',
      origin: 'Germany',
      logo: brandLogos.hettich,
      specialty: 'Hinges, Drawer Systems, Channels',
      description: 'Hettich represents German precision engineering in furniture fittings. With a legacy spanning over 130 years, Hettich delivers innovative drawer systems, hinges, and sliding door hardware that set industry standards for quality and functionality.',
      products: ['InnoTech drawer systems', 'Sensys hinges', 'Sliding door systems', 'Folding door fittings', 'Furniture locks']
    },
    {
      id: 4,
      name: 'Grass',
      origin: 'Austria',
      logo: brandLogos.grass,
      specialty: 'Tandem Box & Drawer Systems',
      description: 'Grass is an Austrian manufacturer renowned for innovative drawer systems, hinges, and movement systems. Their precision-engineered products deliver smooth, silent, and reliable performance for premium furniture applications.',
      products: ['Nova Pro drawer systems', 'Tipmatic push-to-open', 'Tiomos hinges', 'Vionaro drawer systems', 'Kinvaro lift systems']
    },
    {
      id: 5,
      name: 'Labacha',
      origin: 'India',
      logo: brandLogos.labacha,
      specialty: 'Architectural & Cabinet Handles',
      description: 'Labacha specializes in premium architectural hardware with a focus on designer handles and cabinet fittings. Their products combine aesthetic appeal with durability, making them ideal for modern residential and commercial interiors.',
      products: ['Cabinet handles', 'Door pulls', 'Knobs', 'Towel rails', 'Coat hooks']
    }
  ];

  return (
    <div className="bg-[#0a0a0a]">
      {/* Hero Section */}
      <section className="relative py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#121212] to-[#0a0a0a]" />
        <div className="absolute inset-0 opacity-[0.02]" style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, #d4af37 1px, transparent 0)`,
          backgroundSize: '50px 50px'
        }} />
        
        <div className="container-custom relative z-10">
          <div className="max-w-3xl">
            <span className="text-[#d4af37] text-sm font-semibold tracking-[0.2em] uppercase">Our Partners</span>
            <h1 className="text-5xl md:text-6xl font-bold text-white mt-4 mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Brands We <span className="gold-text">Work With</span>
            </h1>
            <p className="text-white/60 text-lg">
              We partner with world-renowned brands to bring you the finest quality hardware and interior solutions.
            </p>
          </div>
        </div>
      </section>

      {/* Brands Logo Bar */}
      <section className="py-12 bg-[#121212] border-y border-[#1a1a1a]">
        <div className="container-custom">
          <div className="flex flex-wrap justify-center items-center gap-12 md:gap-16">
            {detailedBrands.map((brand) => (
              <div key={brand.id} className="opacity-60 hover:opacity-100 transition-opacity">
                <img 
                  src={brand.logo} 
                  alt={brand.name}
                  className="h-10 md:h-12 w-auto object-contain filter grayscale hover:grayscale-0 transition-all"
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Detailed Brand Cards */}
      <section className="py-24 bg-[#0a0a0a]">
        <div className="container-custom">
          <div className="space-y-12">
            {detailedBrands.map((brand, index) => (
              <div 
                key={brand.id} 
                className="bg-[#121212] border border-[#1a1a1a] rounded-2xl overflow-hidden hover:border-[#d4af37]/20 transition-colors"
              >
                <div className={`lg:flex ${index % 2 === 1 ? 'lg:flex-row-reverse' : ''}`}>
                  {/* Brand Info */}
                  <div className="lg:w-2/3 p-8 lg:p-12">
                    <div className="flex items-center gap-6 mb-6">
                      <div className="h-16 flex items-center">
                        <img 
                          src={brand.logo} 
                          alt={brand.name}
                          className="h-full w-auto object-contain"
                        />
                      </div>
                      <div className="flex items-center gap-2 text-sm text-white/50">
                        <Globe size={14} className="text-[#d4af37]" />
                        {brand.origin}
                      </div>
                    </div>
                    
                    <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-[#d4af37]/10 text-[#d4af37] rounded-full text-sm font-medium mb-4">
                      <Award size={14} />
                      {brand.specialty}
                    </div>
                    
                    <p className="text-white/60 mb-6 leading-relaxed">{brand.description}</p>
                    
                    <div>
                      <h4 className="font-semibold text-white mb-3 text-sm">Products Available:</h4>
                      <div className="flex flex-wrap gap-2">
                        {brand.products.map((product, idx) => (
                          <span key={idx} className="px-3 py-1.5 bg-[#1a1a1a] border border-[#252525] text-white/60 rounded-lg text-sm">
                            {product}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  {/* Brand Visual */}
                  <div className="lg:w-1/3 bg-gradient-to-br from-[#1a1a1a] to-[#0a0a0a] p-8 lg:p-12 flex flex-col justify-center items-center border-t lg:border-t-0 lg:border-l border-[#1a1a1a]">
                    <div className="w-32 h-32 rounded-2xl flex items-center justify-center mb-6 bg-white/5 border border-white/10">
                      <img 
                        src={brand.logo} 
                        alt={brand.name}
                        className="max-h-16 max-w-[80%] object-contain"
                      />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-1" style={{ fontFamily: 'Poppins, sans-serif' }}>
                      {brand.name}
                    </h3>
                    <p className="text-white/40 text-sm">{brand.specialty}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Premium Experience Centres */}
      <section className="py-24 bg-[#121212] border-t border-[#1a1a1a]">
        <div className="container-custom">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-[#d4af37] text-sm font-semibold tracking-[0.2em] uppercase">Experience Centres</span>
            <h2 className="text-4xl md:text-5xl font-bold text-white mt-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Premium Brand <span className="gold-text">Showrooms</span>
            </h2>
            <p className="text-white/50 mt-4">
              Visit our dedicated experience centres for Blum and Astronea.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <Link to="/blum" className="group">
              <div className="bg-[#1a1a1a] rounded-xl p-8 border border-[#252525] transition-all group-hover:border-[#F7941D]/30 group-hover:bg-[#1a1a1a]">
                <div className="flex items-center gap-4 mb-6">
                  <img 
                    src={brandLogos.blum} 
                    alt="Blum Logo"
                    className="h-12 w-auto object-contain"
                  />
                </div>
                <p className="text-white/60 mb-6">
                  Austrian precision in furniture fittings. Explore AVENTOS lift systems, LEGRABOX drawers, motion technologies, and more.
                </p>
                <div className="flex flex-wrap gap-2 mb-6">
                  {['Lift Systems', 'Drawer Systems', 'Hinges', 'Motion Tech'].map((item, idx) => (
                    <span key={idx} className="px-3 py-1 bg-[#F7941D]/10 text-[#F7941D] rounded-full text-sm">
                      {item}
                    </span>
                  ))}
                </div>
                <span className="inline-flex items-center text-[#F7941D] font-medium group-hover:gap-3 transition-all">
                  Explore Blum <ArrowRight size={18} className="ml-2" />
                </span>
              </div>
            </Link>
            
            <Link to="/astronea" className="group">
              <div className="bg-[#1a1a1a] rounded-xl p-8 border border-[#252525] transition-all group-hover:border-[#8BC34A]/30 group-hover:bg-[#1a1a1a]">
                <div className="flex items-center gap-4 mb-6">
                  <img 
                    src={brandLogos.astronea} 
                    alt="Astronea Logo"
                    className="h-12 w-auto object-contain"
                  />
                </div>
                <p className="text-white/60 mb-6">
                  Italian design excellence. Discover modular wardrobes, door systems, partition solutions, and premium interior systems.
                </p>
                <div className="flex flex-wrap gap-2 mb-6">
                  {['Wardrobes', 'Door Systems', 'Partitions', 'Shower Enclosures'].map((item, idx) => (
                    <span key={idx} className="px-3 py-1 bg-[#8BC34A]/10 text-[#8BC34A] rounded-full text-sm">
                      {item}
                    </span>
                  ))}
                </div>
                <span className="inline-flex items-center text-[#8BC34A] font-medium group-hover:gap-3 transition-all">
                  Explore Astronea <ArrowRight size={18} className="ml-2" />
                </span>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-[#0a0a0a]">
        <div className="container-custom text-center">
          <h2 className="text-3xl font-bold text-white mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Looking for Specific Brand Products?
          </h2>
          <p className="text-white/50 mb-8">
            Contact us to learn more about availability and specifications.
          </p>
          <Link to="/contact">
            <Button className="btn-gold-gradient font-semibold px-8 border-0">
              Contact Us <ArrowRight size={16} className="ml-2" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default BrandsPage;
