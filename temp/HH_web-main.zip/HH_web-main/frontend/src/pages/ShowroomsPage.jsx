import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, MapPin, Phone, Clock, Check } from 'lucide-react';
import { Button } from '../components/ui/button';
import { companyInfo, brandLogos } from '../data/mock';

const ShowroomsPage = () => {
  return (
    <div className="bg-[#0a0a0a]">
      {/* Hero Section */}
      <section className="relative py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#121212] to-[#0a0a0a]" />
        <div className="absolute inset-0 opacity-[0.02]" style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, #d4af37 1px, transparent 0)`,
          backgroundSize: '50px 50px'
        }} />
        
        <div className="container-custom relative z-10">
          <div className="max-w-3xl">
            <span className="text-[#d4af37] text-sm font-semibold tracking-[0.2em] uppercase">Visit Us</span>
            <h1 className="text-5xl md:text-6xl font-bold text-white mt-4 mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Our <span className="gold-text">Showrooms</span>
            </h1>
            <p className="text-white/60 text-lg">
              Experience our complete range of premium interior solutions across three dedicated zones, all under one roof.
            </p>
          </div>
        </div>
      </section>

      {/* One Building, Three Experiences */}
      <section className="py-24 bg-[#121212]">
        <div className="container-custom">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-[#d4af37] text-sm font-semibold tracking-[0.2em] uppercase">One Building</span>
            <h2 className="text-4xl md:text-5xl font-bold text-white mt-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Three Premium <span className="gold-text">Experiences</span>
            </h2>
            <p className="text-white/50 mt-4">
              All our showrooms are located in one building across different floors, making it convenient for you to explore complete interior solutions in a single visit.
            </p>
          </div>
          
          {/* Building Visualization */}
          <div className="max-w-4xl mx-auto">
            <div className="relative bg-[#1a1a1a] border border-[#252525] rounded-2xl p-8 md:p-12">
              {/* Building Icon */}
              <div className="absolute -top-6 left-1/2 -translate-x-1/2 w-12 h-12 bg-gradient-to-br from-[#d4af37] to-[#c9a227] rounded-full flex items-center justify-center shadow-lg shadow-[#d4af37]/20">
                <MapPin className="text-[#0a0a0a]" size={24} />
              </div>
              
              <div className="space-y-4 mt-4">
                {/* Second Floor - Astronea */}
                <div className="bg-[#0a0a0a] border border-[#8BC34A]/30 rounded-xl p-6 relative">
                  <div className="absolute -left-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-[#8BC34A] rounded-full flex items-center justify-center text-white text-xs font-bold">
                    2
                  </div>
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <img src={brandLogos.astronea} alt="Astronea" className="h-10 w-auto" />
                      <div>
                        <p className="text-white/50 text-sm">Second Floor</p>
                      </div>
                    </div>
                    <Link to="/astronea">
                      <Button className="bg-[#8BC34A] hover:bg-[#7cb342] text-white" size="sm">
                        Explore <ArrowRight size={14} className="ml-1" />
                      </Button>
                    </Link>
                  </div>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {['Walk-in Wardrobes', 'Sliding Systems', 'Door Solutions', 'Partition Systems'].map((item, idx) => (
                      <span key={idx} className="px-3 py-1 bg-[#121212] text-white/50 rounded-full text-xs">
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
                
                {/* First Floor - Blum */}
                <div className="bg-[#0a0a0a] border border-[#F7941D]/30 rounded-xl p-6 relative">
                  <div className="absolute -left-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-[#F7941D] rounded-full flex items-center justify-center text-white text-xs font-bold">
                    1
                  </div>
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <img src={brandLogos.blum} alt="Blum" className="h-10 w-auto" />
                      <div>
                        <p className="text-white/50 text-sm">First Floor</p>
                      </div>
                    </div>
                    <Link to="/blum">
                      <Button className="bg-[#F7941D] hover:bg-[#e58a1a] text-white" size="sm">
                        Explore <ArrowRight size={14} className="ml-1" />
                      </Button>
                    </Link>
                  </div>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {['AVENTOS Lift Systems', 'LEGRABOX Drawers', 'Motion Technologies', 'Hinges'].map((item, idx) => (
                      <span key={idx} className="px-3 py-1 bg-[#121212] text-white/50 rounded-full text-xs">
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
                
                {/* Ground Floor - HH */}
                <div className="bg-[#0a0a0a] border border-[#d4af37]/30 rounded-xl p-6 relative">
                  <div className="absolute -left-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-[#d4af37] rounded-full flex items-center justify-center text-[#0a0a0a] text-xs font-bold">
                    G
                  </div>
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-[#d4af37]/10 rounded-lg flex items-center justify-center">
                        <span className="text-lg font-bold gold-text">HH</span>
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-white" style={{ fontFamily: 'Poppins, sans-serif' }}>
                          Hyderabad Hardware
                        </h3>
                        <p className="text-white/50 text-sm">Ground Floor</p>
                      </div>
                    </div>
                    <Link to="/products">
                      <Button className="btn-gold-gradient border-0" size="sm">
                        View Products <ArrowRight size={14} className="ml-1" />
                      </Button>
                    </Link>
                  </div>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {['Cabinet Hardware', 'Door Handles', 'Locks & Cylinders', 'Drawer Systems'].map((item, idx) => (
                      <span key={idx} className="px-3 py-1 bg-[#121212] text-white/50 rounded-full text-xs">
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Showroom Details */}
      <section className="py-24 bg-[#0a0a0a]">
        <div className="container-custom">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Store */}
            <div className="bg-[#121212] border border-[#1a1a1a] rounded-xl overflow-hidden hover:border-[#d4af37]/20 transition-colors">
              <div className="h-48 bg-gradient-to-br from-[#1a1a1a] to-[#0a0a0a] flex items-center justify-center relative">
                <div className="absolute inset-0 bg-gradient-to-br from-[#d4af37]/5 to-transparent" />
                <div className="text-center relative z-10">
                  <div className="w-20 h-20 bg-[#d4af37]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold gold-text">HH</span>
                  </div>
                  <h3 className="text-xl font-bold text-white" style={{ fontFamily: 'Poppins, sans-serif' }}>
                    Hyderabad Hardware
                  </h3>
                  <p className="text-white/50 text-sm">Ground Floor</p>
                </div>
              </div>
              <div className="p-6">
                <p className="text-white/60 mb-4 text-sm">
                  Our main hardware store featuring a complete range of furniture fittings, door hardware, and cabinet solutions from multiple premium brands.
                </p>
                <h4 className="font-semibold text-white mb-3 text-sm">Highlights:</h4>
                <div className="space-y-2">
                  {['Cabinet handles & pulls', 'Hinges & channels', 'Drawer runners & systems', 'Door locks & handles', 'Cylinders & closers'].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm text-white/50">
                      <Check size={12} className="text-[#d4af37]" />
                      {item}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Blum Centre */}
            <div className="bg-[#121212] border border-[#1a1a1a] rounded-xl overflow-hidden hover:border-[#F7941D]/20 transition-colors">
              <div className="h-48 bg-gradient-to-br from-[#F7941D]/20 to-[#0a0a0a] flex items-center justify-center relative">
                <div className="text-center relative z-10">
                  <img src={brandLogos.blum} alt="Blum" className="h-12 w-auto mx-auto mb-4" />
                  <p className="text-white/60 text-sm">First Floor</p>
                </div>
              </div>
              <div className="p-6">
                <p className="text-white/60 mb-4 text-sm">
                  Dedicated Blum showcase featuring Austrian motion technologies, lift systems, and drawer innovations with live demonstrations.
                </p>
                <h4 className="font-semibold text-white mb-3 text-sm">Highlights:</h4>
                <div className="space-y-2">
                  {['AVENTOS lift systems', 'LEGRABOX drawer systems', 'CLIP top BLUMOTION hinges', 'Motion technologies demo', 'Expert consultations'].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm text-white/50">
                      <Check size={12} className="text-[#F7941D]" />
                      {item}
                    </div>
                  ))}
                </div>
                <Link to="/blum" className="inline-flex items-center text-[#F7941D] font-medium text-sm mt-4">
                  Learn more <ArrowRight size={14} className="ml-1" />
                </Link>
              </div>
            </div>

            {/* Astronea Centre */}
            <div className="bg-[#121212] border border-[#1a1a1a] rounded-xl overflow-hidden hover:border-[#8BC34A]/20 transition-colors">
              <div className="h-48 bg-gradient-to-br from-[#8BC34A]/20 to-[#0a0a0a] flex items-center justify-center relative">
                <div className="text-center relative z-10">
                  <img src={brandLogos.astronea} alt="Astronea" className="h-12 w-auto mx-auto mb-4" />
                  <p className="text-white/60 text-sm">Second Floor</p>
                </div>
              </div>
              <div className="p-6">
                <p className="text-white/60 mb-4 text-sm">
                  Italian wardrobe concept showroom displaying modular wardrobes, door systems, and premium interior solutions.
                </p>
                <h4 className="font-semibold text-white mb-3 text-sm">Highlights:</h4>
                <div className="space-y-2">
                  {['Walk-in wardrobes', 'Sliding wardrobe systems', 'Full glass wardrobes', 'Door & partition systems', 'Design consultations'].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm text-white/50">
                      <Check size={12} className="text-[#8BC34A]" />
                      {item}
                    </div>
                  ))}
                </div>
                <Link to="/astronea" className="inline-flex items-center text-[#8BC34A] font-medium text-sm mt-4">
                  Learn more <ArrowRight size={14} className="ml-1" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Location & Hours */}
      <section className="py-24 bg-[#121212] border-t border-[#1a1a1a]">
        <div className="container-custom">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-[#d4af37] text-sm font-semibold tracking-[0.2em] uppercase">Visit Us</span>
              <h2 className="text-4xl md:text-5xl font-bold text-white mt-4 mb-8" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Location & <span className="gold-text">Hours</span>
              </h2>
              
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#d4af37]/10 rounded-lg flex items-center justify-center shrink-0">
                    <MapPin className="text-[#d4af37]" size={24} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white mb-2">Address</h4>
                    <p className="text-white/60 text-sm">
                      {companyInfo.address.line1}<br />
                      {companyInfo.address.line2}<br />
                      {companyInfo.address.line3}<br />
                      {companyInfo.address.city}, {companyInfo.address.state}<br />
                      {companyInfo.address.country}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#d4af37]/10 rounded-lg flex items-center justify-center shrink-0">
                    <Clock className="text-[#d4af37]" size={24} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white mb-2">Business Hours</h4>
                    <p className="text-white/60 text-sm">
                      Monday - Saturday: 10:00 AM - 8:00 PM<br />
                      Sunday: By Appointment Only
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#d4af37]/10 rounded-lg flex items-center justify-center shrink-0">
                    <Phone className="text-[#d4af37]" size={24} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white mb-2">Contact</h4>
                    <p className="text-white/60 text-sm">
                      {companyInfo.phones[0]}<br />
                      {companyInfo.phones[1]}
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="mt-8">
                <Link to="/contact">
                  <Button className="btn-gold-gradient font-semibold px-8 border-0">
                    Get Directions <ArrowRight size={16} className="ml-2" />
                  </Button>
                </Link>
              </div>
            </div>
            
            <div className="bg-[#1a1a1a] border border-[#252525] rounded-xl p-8">
              <div className="aspect-video rounded-lg overflow-hidden bg-[#0a0a0a]">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3807.4!2d78.4!3d17.4!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTfCsDI0JzAwLjAiTiA3OMKwMjQnMDAuMCJF!5e0!3m2!1sen!2sin!4v1234567890"
                  width="100%"
                  height="100%"
                  style={{ border: 0, minHeight: '300px' }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Hyderabad Hardware Location"
                />
              </div>
              <p className="text-white/40 text-sm mt-4 text-center">
                Srinagar Colony, Hyderabad • Near Sai Avenue
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-[#0a0a0a]">
        <div className="container-custom text-center">
          <h2 className="text-2xl font-bold text-white mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Ready to Visit?
          </h2>
          <p className="text-white/50 mb-6">
            Contact us to schedule a showroom visit or consultation with our experts.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <a href={`tel:${companyInfo.phones[0]}`}>
              <Button className="btn-gold-gradient font-semibold px-8 border-0">
                <Phone size={16} className="mr-2" />
                Call Now
              </Button>
            </a>
            <Link to="/contact">
              <Button variant="outline" className="border-white/20 text-white hover:bg-white/5 hover:border-[#d4af37]/50 px-8">
                Contact Us
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ShowroomsPage;
