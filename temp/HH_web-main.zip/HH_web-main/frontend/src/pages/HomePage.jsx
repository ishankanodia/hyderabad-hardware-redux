import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Phone, MapPin, Star, ChevronRight } from 'lucide-react';
import { Button } from '../components/ui/button';
import { companyInfo, stats, brands, testimonials, brandLogos } from '../data/mock';

// Hero Section with Immersive Background
const HeroSection = () => (
  <section className="relative min-h-screen flex items-center overflow-hidden">
    {/* Background Image with Dark Overlay */}
    <div className="absolute inset-0">
      <img
        src="https://www.blum.com/images/600/400/4173680/corporate/media/bilder/produkte/boxsysteme/legrabox-design/me18652786_aa_fot_fo_bau_-sall_-amc_-v1_3:2.jpg"
        alt="Premium Kitchen Interior"
        className="w-full h-full object-cover"
      />
      {/* Multi-layer gradient overlay for depth */}
      <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a] via-[#0a0a0a]/95 to-[#0a0a0a]/70" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-[#0a0a0a]/50" />
      {/* Warm amber light effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-transparent via-transparent to-[#d4af37]/5" />
    </div>
    
    {/* Gold Accent Line */}
    <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-transparent via-[#d4af37] to-transparent opacity-60" />
    
    {/* Subtle Pattern Overlay */}
    <div className="absolute inset-0 opacity-[0.02]" style={{
      backgroundImage: `radial-gradient(circle at 2px 2px, #d4af37 1px, transparent 0)`,
      backgroundSize: '60px 60px'
    }} />
    
    <div className="container-custom relative z-10 py-32">
      <div className="max-w-3xl">
        {/* Premium Badge */}
        <div className="inline-flex items-center gap-3 px-5 py-2.5 bg-[#d4af37]/10 border border-[#d4af37]/30 rounded-full mb-8 backdrop-blur-sm">
          <span className="w-2 h-2 bg-[#d4af37] rounded-full animate-pulse" />
          <span className="text-[#d4af37] text-sm font-medium tracking-wide">Premium Interior Solutions</span>
        </div>
        
        {/* Headline */}
        <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-[1.1] mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
          Crafting Spaces with
          <span className="block mt-3 gold-text-shimmer">Excellence & Precision</span>
        </h1>
        
        {/* Subheadline */}
        <p className="text-lg md:text-xl text-white/60 max-w-2xl leading-relaxed mb-10">
          Experience world-class architectural hardware, kitchen systems, wardrobe solutions, and furniture fittings at Hyderabad's premier interior hardware destination.
        </p>
        
        {/* CTA Buttons */}
        <div className="flex flex-wrap gap-4 mb-16">
          <Link to="/showrooms">
            <Button size="lg" className="btn-gold-gradient font-semibold px-8 h-14 text-base border-0">
              Visit Our Showroom
              <ArrowRight className="ml-2" size={20} />
            </Button>
          </Link>
          <a href={`tel:${companyInfo.phones[0]}`}>
            <Button size="lg" variant="outline" className="border-white/20 text-white hover:bg-white/5 hover:border-[#d4af37]/50 px-8 h-14 text-base backdrop-blur-sm">
              <Phone className="mr-2" size={20} />
              Call Now
            </Button>
          </a>
        </div>
        
        {/* Stats Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 pt-10 border-t border-white/10">
          {stats.map((stat, index) => (
            <div key={index} className="text-center md:text-left">
              <p className="text-3xl md:text-4xl font-bold gold-text mb-1" style={{ fontFamily: 'Poppins, sans-serif' }}>
                {stat.value}
              </p>
              <p className="text-sm text-white/40">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
    
    {/* Scroll Indicator */}
    <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/30">
      <span className="text-xs tracking-widest uppercase">Scroll</span>
      <div className="w-px h-10 bg-gradient-to-b from-[#d4af37] to-transparent" />
    </div>
  </section>
);

// Experience Centres Section
const ExperienceCentresSection = () => (
  <section className="py-24 bg-[#0a0a0a] relative overflow-hidden">
    {/* Ambient Light */}
    <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-gradient-to-bl from-[#d4af37]/5 to-transparent pointer-events-none" />
    
    <div className="container-custom relative z-10">
      <div className="text-center max-w-2xl mx-auto mb-16">
        <span className="text-[#d4af37] text-sm font-semibold tracking-[0.2em] uppercase">Experience Centres</span>
        <h2 className="text-4xl md:text-5xl font-bold text-white mt-4 mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
          World-Class Brand <span className="gold-text">Experiences</span>
        </h2>
        <p className="text-white/50">
          Discover premium solutions at our dedicated experience centres, all under one roof.
        </p>
      </div>
      
      <div className="grid md:grid-cols-2 gap-8">
        {/* Blum Experience Centre */}
        <Link to="/blum" className="group">
          <div className="relative h-[480px] rounded-2xl overflow-hidden premium-card">
            <img
              src="https://www.blum.com/images/600/400/4053381/localmedia/in/homepage/aventos-top-(1)_3:2.jpg"
              alt="Blum Experience Centre"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/60 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <img 
                src={brandLogos.blum} 
                alt="Blum Logo" 
                className="h-10 w-auto object-contain mb-4"
              />
              <p className="text-white/70 mb-4 line-clamp-2">
                Austrian precision in furniture fittings. Explore AVENTOS lift systems, drawer systems, and motion technologies.
              </p>
              <span className="inline-flex items-center text-[#F7941D] font-medium group-hover:gap-3 transition-all">
                Explore Blum <ArrowRight size={18} className="ml-2" />
              </span>
            </div>
          </div>
        </Link>
        
        {/* Astronea Experience Centre */}
        <Link to="/astronea" className="group">
          <div className="relative h-[480px] rounded-2xl overflow-hidden premium-card">
            <img
              src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&auto=format&fit=crop&q=60"
              alt="Astronea Experience Centre"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/60 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <img 
                src={brandLogos.astronea} 
                alt="Astronea Logo" 
                className="h-10 w-auto object-contain mb-4"
              />
              <p className="text-white/70 mb-4 line-clamp-2">
                Italian design excellence. Discover modular wardrobes, door systems, and premium interior solutions.
              </p>
              <span className="inline-flex items-center text-[#8BC34A] font-medium group-hover:gap-3 transition-all">
                Explore Astronea <ArrowRight size={18} className="ml-2" />
              </span>
            </div>
          </div>
        </Link>
      </div>
    </div>
  </section>
);

// Products Overview Section
const ProductsSection = () => (
  <section className="py-24 bg-[#121212] relative overflow-hidden">
    {/* Subtle texture */}
    <div className="absolute inset-0 grain-texture" />
    
    <div className="container-custom relative z-10">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-end gap-6 mb-16">
        <div>
          <span className="text-[#d4af37] text-sm font-semibold tracking-[0.2em] uppercase">Our Solutions</span>
          <h2 className="text-4xl md:text-5xl font-bold text-white mt-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Premium Interior <span className="gold-text">Solutions</span>
          </h2>
          <p className="text-white/50 mt-4 max-w-xl">
            From cabinet hardware to complete door systems, we offer comprehensive solutions for every interior need.
          </p>
        </div>
        <Link to="/products">
          <Button variant="outline" className="border-[#d4af37]/30 text-[#d4af37] hover:bg-[#d4af37]/10 hover:border-[#d4af37]">
            View All Products <ArrowRight size={16} className="ml-2" />
          </Button>
        </Link>
      </div>
      
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[
          {
            title: "Furniture & Cabinet Hardware",
            description: "Premium handles, hinges, channels, and drawer systems for kitchens, wardrobes, and furniture.",
            image: "https://www.blum.com/images/235/177/4180377/corporate/media/bilder/produkte/fuehrungssysteme/AA_FOT_FO_BAU_ME11575182_-SALL_-AMC_-V1_4:3.jpg"
          },
          {
            title: "Door Hardware & Locking",
            description: "Main door handles, mortise systems, lock bodies, cylinders, and door closers.",
            image: "https://www.blum.com/images/235/177/4180375/corporate/media/bilder/produkte/scharniersysteme/overview/me9974430_4:3.jpg"
          },
          {
            title: "Wardrobe Systems",
            description: "Openable, sliding, and walk-in wardrobe solutions with Italian design aesthetics.",
            image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&auto=format&fit=crop&q=60"
          },
          {
            title: "Lift Systems",
            description: "AVENTOS lift systems for wall cabinets with soft-close and stay-open functions.",
            image: "https://www.blum.com/images/600/400/4053381/localmedia/in/homepage/aventos-top-(1)_3:2.jpg"
          },
          {
            title: "Door & Partition Systems",
            description: "Swing doors, sliding doors, partition systems, and sliding-folding mechanisms.",
            image: "https://www.blum.com/images/600/400/4179638/corporate/media/bilder/produkte/pocketsysteme/blum_revego_me-25342742_3:2.jpg"
          },
          {
            title: "Motion Technologies",
            description: "Soft-close, push-to-open, and electric opening systems for smooth operation.",
            image: "https://www.blum.com/images/235/177/4180381/corporate/media/bilder/produkte/bewegungstechnologien/4-fuer-mehr/img2600_aa_fot_fo_bau_-sall_-am_-v2_4:3.jpg"
          }
        ].map((product, index) => (
          <Link key={index} to="/products" className="group">
            <div className="bg-[#1a1a1a] rounded-xl overflow-hidden premium-card h-full border border-[#252525]">
              <div className="relative h-48 overflow-hidden">
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a] to-transparent opacity-60" />
              </div>
              <div className="p-6">
                <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-[#d4af37] transition-colors" style={{ fontFamily: 'Poppins, sans-serif' }}>
                  {product.title}
                </h3>
                <p className="text-white/50 text-sm">{product.description}</p>
                <span className="inline-flex items-center text-[#d4af37] font-medium text-sm mt-4 group-hover:gap-2 transition-all">
                  Learn More <ChevronRight size={16} />
                </span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  </section>
);

// Brands Section with Logos
const BrandsSection = () => (
  <section className="py-24 bg-[#0a0a0a] relative">
    <div className="container-custom">
      <div className="text-center max-w-2xl mx-auto mb-16">
        <span className="text-[#d4af37] text-sm font-semibold tracking-[0.2em] uppercase">Trusted Partners</span>
        <h2 className="text-4xl md:text-5xl font-bold text-white mt-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
          Brands We <span className="gold-text">Work With</span>
        </h2>
        <p className="text-white/50 mt-4">
          We partner with world-renowned brands to bring you the finest quality hardware and interior solutions.
        </p>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
        {brands.map((brand) => (
          <div key={brand.id} className="group">
            <div className="bg-[#121212] border border-[#1a1a1a] rounded-xl p-6 h-28 flex items-center justify-center transition-all duration-300 group-hover:border-[#d4af37]/30 group-hover:bg-[#1a1a1a]">
              <img 
                src={brand.logo} 
                alt={brand.name} 
                className="max-h-12 w-auto object-contain opacity-70 group-hover:opacity-100 transition-opacity filter grayscale group-hover:grayscale-0"
              />
            </div>
          </div>
        ))}
      </div>
      
      <div className="text-center mt-12">
        <Link to="/brands">
          <Button className="bg-[#1a1a1a] hover:bg-[#252525] text-white border border-[#333] hover:border-[#d4af37]/30">
            View All Brands <ArrowRight size={16} className="ml-2" />
          </Button>
        </Link>
      </div>
    </div>
  </section>
);

// Testimonials Section
const TestimonialsSection = () => (
  <section className="py-24 bg-[#121212] relative overflow-hidden">
    {/* Ambient glow */}
    <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-[#d4af37]/5 rounded-full blur-3xl pointer-events-none" />
    
    <div className="container-custom relative z-10">
      <div className="text-center max-w-2xl mx-auto mb-16">
        <span className="text-[#d4af37] text-sm font-semibold tracking-[0.2em] uppercase">Testimonials</span>
        <h2 className="text-4xl md:text-5xl font-bold text-white mt-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
          What Our <span className="gold-text">Clients Say</span>
        </h2>
      </div>
      
      <div className="grid md:grid-cols-3 gap-8">
        {testimonials.map((testimonial) => (
          <div key={testimonial.id} className="bg-[#1a1a1a] border border-[#252525] rounded-xl p-8 relative group hover:border-[#d4af37]/20 transition-colors">
            <div className="absolute top-6 right-6 text-[#d4af37]/10 text-7xl font-serif">"</div>
            <div className="flex gap-1 mb-4">
              {[...Array(testimonial.rating)].map((_, i) => (
                <Star key={i} size={14} className="fill-[#d4af37] text-[#d4af37]" />
              ))}
            </div>
            <p className="text-white/70 mb-6 relative z-10 leading-relaxed">"{testimonial.quote}"</p>
            <div>
              <p className="font-semibold text-white">{testimonial.name}</p>
              <p className="text-white/40 text-sm">{testimonial.role}, {testimonial.company}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);

// CTA Section
const CTASection = () => (
  <section className="py-24 bg-[#0a0a0a] relative overflow-hidden">
    {/* Background with warm lighting effect */}
    <div className="absolute inset-0">
      <div className="absolute inset-0 bg-gradient-to-br from-[#1a1a1a] via-[#121212] to-[#0a0a0a]" />
      <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-[#d4af37]/5 to-transparent" />
      <div className="absolute bottom-0 left-0 w-1/2 h-1/2 bg-gradient-to-tr from-[#d4af37]/3 to-transparent" />
    </div>
    
    <div className="absolute inset-0 opacity-[0.02]" style={{
      backgroundImage: `radial-gradient(circle at 2px 2px, #d4af37 1px, transparent 0)`,
      backgroundSize: '50px 50px'
    }} />
    
    <div className="container-custom relative z-10">
      <div className="max-w-3xl mx-auto text-center">
        <h2 className="text-4xl md:text-5xl font-bold text-white mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
          Ready to Transform <span className="gold-text">Your Space?</span>
        </h2>
        <p className="text-white/60 text-lg mb-10 max-w-2xl mx-auto">
          Visit our showroom to experience premium hardware solutions firsthand. Our experts are ready to help you create the perfect interior.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Link to="/contact">
            <Button size="lg" className="btn-gold-gradient font-semibold px-10 h-14 text-base border-0">
              <MapPin size={20} className="mr-2" />
              Visit Showroom
            </Button>
          </Link>
          <a href={`tel:${companyInfo.phones[0]}`}>
            <Button size="lg" variant="outline" className="border-white/20 text-white hover:bg-white/5 hover:border-[#d4af37]/50 px-10 h-14 text-base">
              <Phone size={20} className="mr-2" />
              {companyInfo.phones[0]}
            </Button>
          </a>
        </div>
      </div>
    </div>
  </section>
);

// Main Home Page Component
const HomePage = () => {
  return (
    <div className="bg-[#0a0a0a]">
      <HeroSection />
      <ExperienceCentresSection />
      <ProductsSection />
      <BrandsSection />
      <TestimonialsSection />
      <CTASection />
    </div>
  );
};

export default HomePage;
