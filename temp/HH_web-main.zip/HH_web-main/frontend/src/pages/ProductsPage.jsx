import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Check } from 'lucide-react';
import { Button } from '../components/ui/button';
import { brandLogos } from '../data/mock';

const ProductsPage = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  
  const categories = [
    { id: 'all', name: 'All Products' },
    { id: 'furniture', name: 'Furniture & Cabinet' },
    { id: 'door', name: 'Door Hardware' }
  ];

  const allProducts = [
    {
      id: 1,
      category: 'furniture',
      name: 'Cabinet Handles',
      description: 'Premium cabinet handles in various finishes including brass, chrome, nickel, and antique designs for kitchens, wardrobes, and furniture.',
      image: 'https://www.blum.com/images/235/177/4180377/corporate/media/bilder/produkte/fuehrungssysteme/AA_FOT_FO_BAU_ME11575182_-SALL_-AMC_-V1_4:3.jpg',
      features: ['Multiple finishes', 'Various sizes', 'Premium quality']
    },
    {
      id: 2,
      category: 'furniture',
      name: 'Hinges',
      description: 'High-quality hinges including soft-close, concealed, and heavy-duty options for smooth furniture operation.',
      image: 'https://www.blum.com/images/235/177/4180375/corporate/media/bilder/produkte/scharniersysteme/overview/me9974430_4:3.jpg',
      features: ['Soft-close options', 'Concealed designs', '100,000+ cycle tested']
    },
    {
      id: 3,
      category: 'furniture',
      name: 'Drawer Systems & Channels',
      description: 'Tandem box, drawer runners, and channel systems for superior drawer functionality in kitchens and wardrobes.',
      image: 'https://www.blum.com/images/600/400/4053357/localmedia/in/homepage/tandem-runner_3:2-2.jpg',
      features: ['30kg+ load capacity', 'Full extension', 'Smooth glide']
    },
    {
      id: 4,
      category: 'furniture',
      name: 'Lift Systems',
      description: 'AVENTOS lift systems for wall cabinets with stay-open, soft-close, and various opening mechanisms.',
      image: 'https://www.blum.com/images/600/400/4053381/localmedia/in/homepage/aventos-top-(1)_3:2.jpg',
      features: ['Multiple lift types', 'Soft-close', 'Stay-open function']
    },
    {
      id: 5,
      category: 'door',
      name: 'Main Door Handles',
      description: 'Elegant main door handles in premium finishes for residential and commercial entrances.',
      image: 'https://www.blum.com/images/600/400/4179638/corporate/media/bilder/produkte/pocketsysteme/blum_revego_me-25342742_3:2.jpg',
      features: ['Premium finishes', 'Ergonomic design', 'Durable construction']
    },
    {
      id: 6,
      category: 'door',
      name: 'Mortise Handles & Lock Bodies',
      description: 'Complete mortise handle sets with high-security lock bodies for all door types.',
      image: 'https://www.blum.com/images/235/177/4180381/corporate/media/bilder/produkte/bewegungstechnologien/4-fuer-mehr/img2600_aa_fot_fo_bau_-sall_-am_-v2_4:3.jpg',
      features: ['High security', 'Multiple styles', 'Easy installation']
    },
    {
      id: 7,
      category: 'door',
      name: 'Cylinders',
      description: 'Security cylinders in various grades and configurations for residential and commercial applications.',
      image: 'https://www.blum.com/images/600/400/4173680/corporate/media/bilder/produkte/boxsysteme/legrabox-design/me18652786_aa_fot_fo_bau_-sall_-amc_-v1_3:2.jpg',
      features: ['Anti-pick', 'Anti-drill', 'Key control']
    },
    {
      id: 8,
      category: 'door',
      name: 'Door Closers',
      description: 'Smooth-operating door closers for all door types including fire doors and automatic systems.',
      image: 'https://www.blum.com/images/600/400/4180617/corporate/media/bilder/produkte/schrankanwendungen/SPACESTEP0003_3:2.jpg',
      features: ['Adjustable speed', 'Fire-rated options', 'Heavy-duty']
    }
  ];

  const filteredProducts = activeCategory === 'all' 
    ? allProducts 
    : allProducts.filter(p => p.category === activeCategory);

  return (
    <div className="bg-[#0a0a0a]">
      {/* Hero Section */}
      <section className="relative py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#121212] to-[#0a0a0a]" />
        <div className="absolute inset-0 opacity-[0.02]" style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, #d4af37 1px, transparent 0)`,
          backgroundSize: '50px 50px'
        }} />
        
        <div className="container-custom relative z-10">
          <div className="max-w-3xl">
            <span className="text-[#d4af37] text-sm font-semibold tracking-[0.2em] uppercase">Our Solutions</span>
            <h1 className="text-5xl md:text-6xl font-bold text-white mt-4 mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Products & <span className="gold-text">Solutions</span>
            </h1>
            <p className="text-white/60 text-lg">
              Comprehensive interior hardware solutions for kitchens, wardrobes, furniture, and architectural applications.
            </p>
          </div>
        </div>
      </section>

      {/* Product Categories */}
      <section className="py-24 bg-[#121212]">
        <div className="container-custom">
          {/* Category Tabs */}
          <div className="flex flex-wrap gap-3 mb-12">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-6 py-3 rounded-full font-medium transition-all ${
                  activeCategory === cat.id
                    ? 'bg-[#d4af37] text-[#0a0a0a]'
                    : 'bg-[#1a1a1a] text-white/70 hover:text-white border border-[#252525] hover:border-[#d4af37]/30'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>

          {/* Products Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <div key={product.id} className="group bg-[#1a1a1a] border border-[#252525] rounded-xl overflow-hidden hover:border-[#d4af37]/30 transition-all">
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a] to-transparent opacity-60" />
                </div>
                <div className="p-6">
                  <span className="text-xs text-[#d4af37] font-medium uppercase tracking-wider">
                    {product.category === 'furniture' ? 'Furniture & Cabinet' : 'Door Hardware'}
                  </span>
                  <h3 className="text-lg font-semibold text-white mt-2 mb-3 group-hover:text-[#d4af37] transition-colors" style={{ fontFamily: 'Poppins, sans-serif' }}>
                    {product.name}
                  </h3>
                  <p className="text-white/50 text-sm mb-4 line-clamp-2">{product.description}</p>
                  <div className="space-y-2">
                    {product.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm text-white/40">
                        <Check size={12} className="text-[#d4af37]" />
                        {feature}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Applications Section */}
      <section className="py-24 bg-[#0a0a0a]">
        <div className="container-custom">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-[#d4af37] text-sm font-semibold tracking-[0.2em] uppercase">Applications</span>
            <h2 className="text-4xl md:text-5xl font-bold text-white mt-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Solutions For <span className="gold-text">Every Space</span>
            </h2>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { name: 'Kitchens', description: 'Drawer systems, hinges, lift systems, handles' },
              { name: 'Wardrobes', description: 'Sliding systems, hinges, accessories, handles' },
              { name: 'Furniture', description: 'Cabinet hardware, runners, motion technologies' },
              { name: 'Commercial', description: 'Door hardware, locks, closers, access control' }
            ].map((app, index) => (
              <div key={index} className="bg-[#121212] border border-[#1a1a1a] p-8 rounded-xl text-center hover:border-[#d4af37]/20 transition-colors">
                <div className="w-16 h-16 bg-[#d4af37]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold gold-text">{app.name.charAt(0)}</span>
                </div>
                <h4 className="text-lg font-semibold text-white mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
                  {app.name}
                </h4>
                <p className="text-white/50 text-sm">{app.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Experience Centres CTA */}
      <section className="py-24 bg-[#121212] border-t border-[#1a1a1a]">
        <div className="container-custom">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-[#d4af37] text-sm font-semibold tracking-[0.2em] uppercase">Premium Brands</span>
            <h2 className="text-4xl md:text-5xl font-bold text-white mt-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Explore Our <span className="gold-text">Experience Centres</span>
            </h2>
            <p className="text-white/50 mt-4">
              Discover world-class solutions at our dedicated brand experience centres.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <Link to="/blum" className="group">
              <div className="relative h-64 rounded-xl overflow-hidden border border-[#252525] group-hover:border-[#F7941D]/30 transition-all">
                <img
                  src="https://www.blum.com/images/600/400/4173680/corporate/media/bilder/produkte/boxsysteme/legrabox-design/me18652786_aa_fot_fo_bau_-sall_-amc_-v1_3:2.jpg"
                  alt="Blum Products"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/60 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <img src={brandLogos.blum} alt="Blum Logo" className="h-8 w-auto mb-2" />
                  <p className="text-white/60 text-sm">Austrian Motion Technologies</p>
                </div>
              </div>
            </Link>
            
            <Link to="/astronea" className="group">
              <div className="relative h-64 rounded-xl overflow-hidden border border-[#252525] group-hover:border-[#8BC34A]/30 transition-all">
                <img
                  src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&auto=format&fit=crop&q=60"
                  alt="Astronea Products"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/60 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <img src={brandLogos.astronea} alt="Astronea Logo" className="h-8 w-auto mb-2" />
                  <p className="text-white/60 text-sm">Italian Wardrobe Concept</p>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16 bg-[#0a0a0a]">
        <div className="container-custom text-center">
          <h2 className="text-2xl font-bold text-white mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Need Help Choosing the Right Products?
          </h2>
          <p className="text-white/50 mb-6">
            Our experts are here to guide you through our extensive product range.
          </p>
          <Link to="/contact">
            <Button className="btn-gold-gradient font-semibold px-8 border-0">
              Contact Us <ArrowRight size={16} className="ml-2" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default ProductsPage;
