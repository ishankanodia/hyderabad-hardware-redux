import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Check, ExternalLink, Phone } from 'lucide-react';
import { Button } from '../components/ui/button';
import { blumProducts, companyInfo, brandLogos } from '../data/mock';

const BlumPage = () => {
  const blumSolutions = [
    {
      id: 1,
      category: 'Lift Systems',
      name: 'AVENTOS',
      description: 'Next-generation lift systems for wall cabinets with effortless operation, soft-close, and stay-open functions.',
      image: 'https://www.blum.com/images/600/400/4053381/localmedia/in/homepage/aventos-top-(1)_3:2.jpg',
      variants: ['AVENTOS HK top', 'AVENTOS HL', 'AVENTOS HF', 'AVENTOS HS', 'AVENTOS HK-S'],
      features: ['Soft-close integrated', 'Stay-open function', 'Multiple opening angles', 'Easy adjustment']
    },
    {
      id: 2,
      category: 'Box Systems',
      name: 'LEGRABOX',
      description: 'Bring inspiring drawer designs to life with slimmest drawer sides and stunning design possibilities.',
      image: 'https://www.blum.com/images/600/400/4173680/corporate/media/bilder/produkte/boxsysteme/legrabox-design/me18652786_aa_fot_fo_bau_-sall_-amc_-v1_3:2.jpg',
      variants: ['LEGRABOX pure', 'LEGRABOX free'],
      features: ['Slimmest drawer sides', 'Premium design', 'Smooth glide', 'High stability']
    },
    {
      id: 3,
      category: 'Runner Systems',
      name: 'TANDEM',
      description: 'Feather-light glide with integrated soft-close, tested for 100,000 cycles.',
      image: 'https://www.blum.com/images/600/400/4053357/localmedia/in/homepage/tandem-runner_3:2-2.jpg',
      variants: ['TANDEM', 'TANDEM plus BLUMOTION', 'TANDEM plus TIP-ON'],
      features: ['30kg load capacity', 'Full extension', '100,000 cycle tested', 'Integrated soft-close']
    },
    {
      id: 4,
      category: 'Hinge Systems',
      name: 'CLIP top BLUMOTION',
      description: 'Wide range of hinges with integrated soft-close for any furniture project.',
      image: 'https://www.blum.com/images/235/177/4180375/corporate/media/bilder/produkte/scharniersysteme/overview/me9974430_4:3.jpg',
      variants: ['CLIP top', 'CLIP top BLUMOTION', 'CLIP top BLUMOTION with TIP-ON'],
      features: ['Soft-close integrated', 'Tool-free adjustment', 'Wide opening angle', 'Easy clip mounting']
    },
    {
      id: 5,
      category: 'Pocket Systems',
      name: 'REVEGO',
      description: 'Expand your design freedom with flexible and multifunctional use of space.',
      image: 'https://www.blum.com/images/600/400/4179638/corporate/media/bilder/produkte/pocketsysteme/blum_revego_me-25342742_3:2.jpg',
      variants: ['REVEGO duo', 'REVEGO uno'],
      features: ['Space optimization', 'Flexible design', 'Multifunctional', 'Premium finish']
    },
    {
      id: 6,
      category: 'Motion Technologies',
      name: 'BLUMOTION & SERVO-DRIVE',
      description: 'Four motion technologies for smooth, effortless furniture operation.',
      image: 'https://www.blum.com/images/235/177/4180381/corporate/media/bilder/produkte/bewegungstechnologien/4-fuer-mehr/img2600_aa_fot_fo_bau_-sall_-am_-v2_4:3.jpg',
      variants: ['BLUMOTION', 'TIP-ON', 'TIP-ON BLUMOTION', 'SERVO-DRIVE'],
      features: ['Soft-close', 'Push-to-open', 'Electric opening', 'Handle-less design']
    }
  ];

  return (
    <div className="bg-[#0a0a0a]">
      {/* Hero Section */}
      <section className="relative py-32 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://www.blum.com/images/600/400/4053381/localmedia/in/homepage/aventos-top-(1)_3:2.jpg"
            alt="Blum Kitchen"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a] via-[#0a0a0a]/95 to-[#0a0a0a]/70" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-[#0a0a0a]/50" />
        </div>
        <div className="absolute inset-0 opacity-[0.02]" style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, #F7941D 1px, transparent 0)`,
          backgroundSize: '50px 50px'
        }} />
        
        <div className="container-custom relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="mb-8">
                <img 
                  src={brandLogos.blum} 
                  alt="Blum Logo" 
                  className="h-14 w-auto object-contain mb-4"
                />
                <span className="text-[#F7941D] text-sm font-semibold tracking-[0.2em] uppercase">Experience Centre by Hyderabad Hardware</span>
              </div>
              
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Austrian Precision in <span className="text-[#F7941D]">Motion Technologies</span>
              </h2>
              
              <p className="text-white/70 text-lg mb-8">
                Blum is a global leader in furniture fittings and motion technologies. Known for functionality, durability, and user comfort, Blum products transform everyday furniture into exceptional experiences.
              </p>
              
              <div className="flex flex-wrap gap-4 mb-8">
                <a href={`tel:${companyInfo.phones[0]}`}>
                  <Button size="lg" className="bg-[#F7941D] hover:bg-[#e58a1a] text-white font-semibold px-8">
                    <Phone size={18} className="mr-2" />
                    Book a Demo
                  </Button>
                </a>
                <a href="https://www.blum.com/in/en/" target="_blank" rel="noopener noreferrer">
                  <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 px-8">
                    <ExternalLink size={18} className="mr-2" />
                    Official Website
                  </Button>
                </a>
              </div>
              
              <div className="flex items-center gap-6 text-sm text-white/60">
                <span className="flex items-center gap-2">
                  <Check size={16} className="text-[#F7941D]" /> Austrian Quality
                </span>
                <span className="flex items-center gap-2">
                  <Check size={16} className="text-[#F7941D]" /> 100,000+ Cycle Tested
                </span>
              </div>
            </div>
            
            <div className="relative hidden lg:block">
              <img
                src="https://www.blum.com/images/600/400/4053381/localmedia/in/homepage/aventos-top-(1)_3:2.jpg"
                alt="Blum AVENTOS"
                className="rounded-xl shadow-2xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-lg shadow-xl">
                <p className="text-xs text-gray-500 mb-1">Located at</p>
                <p className="font-semibold text-[#1a1a1a]">First Floor</p>
                <p className="text-sm text-gray-600">Hyderabad Hardware Building</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Blum */}
      <section className="py-20 bg-white">
        <div className="container-custom">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="text-[#F7941D] text-sm font-semibold tracking-wider uppercase">About Blum</span>
              <h2 className="text-3xl md:text-4xl font-bold text-[#1a1a1a] mt-4 mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Moving Ideas Since 1952
              </h2>
              <div className="space-y-4 text-gray-600">
                <p>
                  Founded in Austria in 1952, Blum has grown to become one of the world's leading manufacturers of furniture fittings. With a presence in over 120 countries, Blum is synonymous with innovation, quality, and precision engineering.
                </p>
                <p>
                  Blum's philosophy centers on enhancing the quality of living through intelligent furniture solutions. Every product is designed with the user in mind – from soft-close mechanisms that prevent slamming to motion technologies that make opening effortless.
                </p>
                <p>
                  At our Blum Experience Centre, you can witness these innovations firsthand. Our trained experts will demonstrate how Blum fittings can transform your kitchen, wardrobe, and furniture projects.
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-[#F7941D]/10 p-8 rounded-xl text-center">
                <p className="text-4xl font-bold text-[#F7941D]">70+</p>
                <p className="text-sm text-gray-600 mt-2">Years of Innovation</p>
              </div>
              <div className="bg-[#F7941D]/10 p-8 rounded-xl text-center">
                <p className="text-4xl font-bold text-[#F7941D]">120+</p>
                <p className="text-sm text-gray-600 mt-2">Countries Served</p>
              </div>
              <div className="bg-[#F7941D]/10 p-8 rounded-xl text-center">
                <p className="text-4xl font-bold text-[#F7941D]">8000+</p>
                <p className="text-sm text-gray-600 mt-2">Employees Worldwide</p>
              </div>
              <div className="bg-[#F7941D]/10 p-8 rounded-xl text-center">
                <p className="text-4xl font-bold text-[#F7941D]">100k</p>
                <p className="text-sm text-gray-600 mt-2">Cycle Tested</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Solutions */}
      <section className="py-20 bg-[#f5f5f5]">
        <div className="container-custom">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-[#F7941D] text-sm font-semibold tracking-wider uppercase">Blum Solutions</span>
            <h2 className="text-3xl md:text-4xl font-bold text-[#1a1a1a] mt-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Products Available at Our Centre
            </h2>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blumSolutions.map((solution) => (
              <div key={solution.id} className="bg-white rounded-xl overflow-hidden premium-card group">
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={solution.image}
                    alt={solution.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 bg-[#F7941D] text-white text-xs font-medium rounded-full">
                      {solution.category}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-[#1a1a1a] mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
                    {solution.name}
                  </h3>
                  <p className="text-gray-600 text-sm mb-4">{solution.description}</p>
                  
                  <div className="mb-4">
                    <p className="text-xs font-semibold text-gray-500 uppercase mb-2">Variants:</p>
                    <div className="flex flex-wrap gap-1">
                      {solution.variants.map((variant, idx) => (
                        <span key={idx} className="px-2 py-1 bg-[#f5f5f5] text-gray-600 rounded text-xs">
                          {variant}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <div className="border-t pt-4">
                    <div className="grid grid-cols-2 gap-2">
                      {solution.features.slice(0, 4).map((feature, idx) => (
                        <div key={idx} className="flex items-center gap-1 text-xs text-gray-500">
                          <Check size={12} className="text-[#F7941D]" />
                          {feature}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Motion Technologies Highlight */}
      <section className="py-20 bg-[#1a1a1a]">
        <div className="container-custom">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-[#F7941D] text-sm font-semibold tracking-wider uppercase">Motion Technologies</span>
              <h2 className="text-3xl md:text-4xl font-bold text-white mt-4 mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
                4 Technologies for More
              </h2>
              <p className="text-white/70 mb-8">
                Blum offers four unique motion technologies that enhance the way furniture moves. Each technology can be used individually, offering distinct benefits for different applications.
              </p>
              
              <div className="grid grid-cols-2 gap-4">
                {[
                  { name: 'BLUMOTION', desc: 'Soft & silent close' },
                  { name: 'TIP-ON', desc: 'Handle-less opening' },
                  { name: 'TIP-ON BLUMOTION', desc: 'Best of both worlds' },
                  { name: 'SERVO-DRIVE', desc: 'Electric opening' }
                ].map((tech, idx) => (
                  <div key={idx} className="bg-[#252525] p-4 rounded-lg">
                    <h4 className="font-semibold text-[#F7941D] mb-1">{tech.name}</h4>
                    <p className="text-white/60 text-sm">{tech.desc}</p>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="relative">
              <img
                src="https://www.blum.com/images/235/177/4180381/corporate/media/bilder/produkte/bewegungstechnologien/4-fuer-mehr/img2600_aa_fot_fo_bau_-sall_-am_-v2_4:3.jpg"
                alt="Blum Motion Technologies"
                className="rounded-xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-[#F7941D] to-[#e58a1a]">
        <div className="container-custom text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Experience Blum at Our Centre
          </h2>
          <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">
            Visit our Blum Experience Centre to see these innovative solutions in action. Our experts are ready to demonstrate and help you choose the right fittings for your project.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/contact">
              <Button size="lg" className="bg-white text-[#F7941D] hover:bg-white/90 font-semibold px-8">
                Visit Showroom <ArrowRight size={18} className="ml-2" />
              </Button>
            </Link>
            <a href={`tel:${companyInfo.phones[0]}`}>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10 px-8">
                <Phone size={18} className="mr-2" />
                {companyInfo.phones[0]}
              </Button>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default BlumPage;
