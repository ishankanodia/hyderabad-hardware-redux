import React, { useState } from 'react';
import { Phone, Mail, MapPin, Clock, Send, Check } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Label } from '../components/ui/label';
import { companyInfo, brandLogos } from '../data/mock';
import { toast } from 'sonner';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    setSubmitted(true);
    toast.success('Thank you! We will contact you soon.');
    
    // Reset form after 3 seconds
    setTimeout(() => {
      setSubmitted(false);
      setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
    }, 3000);
  };

  return (
    <div className="bg-[#0a0a0a]">
      {/* Hero Section */}
      <section className="relative py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#121212] to-[#0a0a0a]" />
        <div className="absolute inset-0 opacity-[0.02]" style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, #d4af37 1px, transparent 0)`,
          backgroundSize: '50px 50px'
        }} />
        
        <div className="container-custom relative z-10">
          <div className="max-w-3xl">
            <span className="text-[#d4af37] text-sm font-semibold tracking-[0.2em] uppercase">Get In Touch</span>
            <h1 className="text-5xl md:text-6xl font-bold text-white mt-4 mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Contact <span className="gold-text">Us</span>
            </h1>
            <p className="text-white/60 text-lg">
              Have questions about our products or services? Ready to visit our showroom? We're here to help.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Cards */}
      <section className="py-12 bg-[#121212] border-y border-[#1a1a1a]">
        <div className="container-custom">
          <div className="grid md:grid-cols-3 gap-6">
            <a href={`tel:${companyInfo.phones[0]}`} className="group">
              <div className="bg-[#1a1a1a] border border-[#252525] p-6 rounded-xl text-center transition-all group-hover:border-[#d4af37]/50 group-hover:bg-[#d4af37]/5">
                <div className="w-14 h-14 bg-[#d4af37]/10 rounded-full flex items-center justify-center mx-auto mb-4 transition-colors group-hover:bg-[#d4af37]/20">
                  <Phone className="text-[#d4af37]" size={24} />
                </div>
                <h3 className="font-semibold text-white mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
                  Call Us
                </h3>
                <p className="text-white/50 text-sm">
                  {companyInfo.phones[0]}<br />
                  {companyInfo.phones[1]}
                </p>
              </div>
            </a>
            
            <a href={`mailto:${companyInfo.emails[0]}`} className="group">
              <div className="bg-[#1a1a1a] border border-[#252525] p-6 rounded-xl text-center transition-all group-hover:border-[#d4af37]/50 group-hover:bg-[#d4af37]/5">
                <div className="w-14 h-14 bg-[#d4af37]/10 rounded-full flex items-center justify-center mx-auto mb-4 transition-colors group-hover:bg-[#d4af37]/20">
                  <Mail className="text-[#d4af37]" size={24} />
                </div>
                <h3 className="font-semibold text-white mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
                  Email Us
                </h3>
                <p className="text-white/50 text-sm">
                  {companyInfo.emails[0]}<br />
                  {companyInfo.emails[1]}
                </p>
              </div>
            </a>
            
            <div className="bg-[#1a1a1a] border border-[#252525] p-6 rounded-xl text-center">
              <div className="w-14 h-14 bg-[#d4af37]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="text-[#d4af37]" size={24} />
              </div>
              <h3 className="font-semibold text-white mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Business Hours
              </h3>
              <p className="text-white/50 text-sm">
                Mon - Sat: 10AM - 8PM<br />
                Sunday: By Appointment
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Contact Section */}
      <section className="py-24 bg-[#0a0a0a]">
        <div className="container-custom">
          <div className="grid lg:grid-cols-2 gap-16">
            {/* Contact Form */}
            <div>
              <span className="text-[#d4af37] text-sm font-semibold tracking-[0.2em] uppercase">Send a Message</span>
              <h2 className="text-3xl md:text-4xl font-bold text-white mt-4 mb-8" style={{ fontFamily: 'Poppins, sans-serif' }}>
                We'd Love to <span className="gold-text">Hear From You</span>
              </h2>
              
              {submitted ? (
                <div className="bg-[#8BC34A]/10 border border-[#8BC34A]/30 rounded-xl p-8 text-center">
                  <div className="w-16 h-16 bg-[#8BC34A]/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Check className="text-[#8BC34A]" size={32} />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-2">Message Sent!</h3>
                  <p className="text-white/60">Thank you for contacting us. We'll get back to you shortly.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-white/70">Full Name *</Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Your name"
                        required
                        className="h-12 bg-[#121212] border-[#252525] text-white placeholder:text-white/30 focus:border-[#d4af37]/50"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-white/70">Email Address *</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="your@email.com"
                        required
                        className="h-12 bg-[#121212] border-[#252525] text-white placeholder:text-white/30 focus:border-[#d4af37]/50"
                      />
                    </div>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="phone" className="text-white/70">Phone Number *</Label>
                      <Input
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        placeholder="Your phone number"
                        required
                        className="h-12 bg-[#121212] border-[#252525] text-white placeholder:text-white/30 focus:border-[#d4af37]/50"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="subject" className="text-white/70">Subject</Label>
                      <Input
                        id="subject"
                        name="subject"
                        value={formData.subject}
                        onChange={handleChange}
                        placeholder="What's this about?"
                        className="h-12 bg-[#121212] border-[#252525] text-white placeholder:text-white/30 focus:border-[#d4af37]/50"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="message" className="text-white/70">Message *</Label>
                    <Textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      placeholder="Tell us about your project or inquiry..."
                      required
                      rows={5}
                      className="resize-none bg-[#121212] border-[#252525] text-white placeholder:text-white/30 focus:border-[#d4af37]/50"
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    disabled={isSubmitting}
                    className="btn-gold-gradient font-semibold px-8 h-12 w-full md:w-auto border-0"
                  >
                    {isSubmitting ? (
                      <span className="flex items-center">
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Sending...
                      </span>
                    ) : (
                      <span className="flex items-center">
                        <Send size={18} className="mr-2" />
                        Send Message
                      </span>
                    )}
                  </Button>
                </form>
              )}
            </div>
            
            {/* Location Info */}
            <div>
              <span className="text-[#d4af37] text-sm font-semibold tracking-[0.2em] uppercase">Visit Our Showroom</span>
              <h2 className="text-3xl md:text-4xl font-bold text-white mt-4 mb-8" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Showroom <span className="gold-text">Location</span>
              </h2>
              
              <div className="bg-[#121212] border border-[#1a1a1a] rounded-xl p-6 mb-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#d4af37]/10 rounded-lg flex items-center justify-center shrink-0">
                    <MapPin className="text-[#d4af37]" size={24} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white mb-2">Address</h4>
                    <p className="text-white/60 text-sm">
                      <strong className="text-white">Hyderabad Hardware</strong><br />
                      {companyInfo.address.line1}<br />
                      {companyInfo.address.line2}<br />
                      {companyInfo.address.line3}<br />
                      {companyInfo.address.city}, {companyInfo.address.state}<br />
                      {companyInfo.address.country}
                    </p>
                  </div>
                </div>
              </div>
              
              {/* Map */}
              <div className="rounded-xl overflow-hidden shadow-lg border border-[#252525]">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3807.4!2d78.4!3d17.4!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTfCsDI0JzAwLjAiTiA3OMKwMjQnMDAuMCJF!5e0!3m2!1sen!2sin!4v1234567890"
                  width="100%"
                  height="300"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Hyderabad Hardware Location"
                  className="grayscale"
                />
              </div>
              
              {/* Quick Actions */}
              <div className="mt-6 grid grid-cols-2 gap-4">
                <a 
                  href={`tel:${companyInfo.phones[0]}`}
                  className="bg-[#1a1a1a] border border-[#252525] text-white p-4 rounded-xl text-center hover:border-[#d4af37]/30 transition-colors"
                >
                  <Phone size={24} className="mx-auto mb-2 text-[#d4af37]" />
                  <span className="font-medium text-sm">Call Now</span>
                </a>
                <a 
                  href={`mailto:${companyInfo.emails[0]}`}
                  className="bg-[#d4af37] text-[#0a0a0a] p-4 rounded-xl text-center hover:bg-[#c9a227] transition-colors"
                >
                  <Mail size={24} className="mx-auto mb-2" />
                  <span className="font-medium text-sm">Email Us</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Experience Centres CTA */}
      <section className="py-16 bg-[#121212] border-t border-[#1a1a1a]">
        <div className="container-custom">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Visit Our <span className="gold-text">Experience Centres</span>
            </h2>
            <p className="text-white/50">
              All located in one building, explore Blum and Astronea showrooms alongside our main hardware store.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-[#1a1a1a] border border-[#252525] p-6 rounded-xl text-center">
              <div className="w-12 h-12 bg-[#d4af37]/10 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-lg font-bold gold-text">HH</span>
              </div>
              <h3 className="font-semibold text-white mb-1">Hyderabad Hardware</h3>
              <p className="text-white/40 text-sm">Ground Floor</p>
            </div>
            
            <div className="bg-[#1a1a1a] border border-[#F7941D]/20 p-6 rounded-xl text-center">
              <div className="mb-3 flex justify-center">
                <img src={brandLogos.blum} alt="Blum" className="h-8 w-auto" />
              </div>
              <p className="text-white/40 text-sm">First Floor</p>
            </div>
            
            <div className="bg-[#1a1a1a] border border-[#8BC34A]/20 p-6 rounded-xl text-center">
              <div className="mb-3 flex justify-center">
                <img src={brandLogos.astronea} alt="Astronea" className="h-8 w-auto" />
              </div>
              <p className="text-white/40 text-sm">Second Floor</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;
