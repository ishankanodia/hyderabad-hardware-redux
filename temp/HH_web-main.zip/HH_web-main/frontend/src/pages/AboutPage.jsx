import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Check, Award, Users, Target, Eye } from 'lucide-react';
import { Button } from '../components/ui/button';
import { stats, brandLogos } from '../data/mock';

const AboutPage = () => {
  return (
    <div className="bg-[#0a0a0a]">
      {/* Hero Section */}
      <section className="relative py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#121212] to-[#0a0a0a]" />
        <div className="absolute inset-0 opacity-[0.02]" style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, #d4af37 1px, transparent 0)`,
          backgroundSize: '50px 50px'
        }} />
        
        <div className="container-custom relative z-10">
          <div className="max-w-3xl">
            <span className="text-[#d4af37] text-sm font-semibold tracking-[0.2em] uppercase">About Us</span>
            <h1 className="text-5xl md:text-6xl font-bold text-white mt-4 mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Hyderabad's Premier <span className="gold-text">Interior Hardware</span> Destination
            </h1>
            <p className="text-white/60 text-lg">
              For over two decades, Hyderabad Hardware has been the trusted partner for architects, interior designers, contractors, and homeowners seeking premium interior solutions.
            </p>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-24 bg-[#121212]">
        <div className="container-custom">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="text-[#d4af37] text-sm font-semibold tracking-[0.2em] uppercase">Our Story</span>
              <h2 className="text-4xl md:text-5xl font-bold text-white mt-4 mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Building Excellence <span className="gold-text">Since Decades</span>
              </h2>
              <div className="space-y-4 text-white/60">
                <p>
                  Hyderabad Hardware began with a simple vision: to bring world-class interior hardware solutions to Hyderabad. What started as a modest hardware store has evolved into a comprehensive interior solutions destination, housing premium brands and dedicated experience centres.
                </p>
                <p>
                  Today, we operate from a multi-floor facility in Srinagar Colony, featuring the main Hyderabad Hardware store alongside dedicated Blum and Astronea Experience Centres – all under one roof, offering an unparalleled shopping experience.
                </p>
                <p>
                  Our commitment to quality, authenticity, and customer satisfaction has made us the preferred choice for professionals and homeowners alike across Telangana and beyond.
                </p>
              </div>
            </div>
            
            <div className="relative">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <img
                    src="https://www.blum.com/images/600/400/4053357/localmedia/in/homepage/tandem-runner_3:2-2.jpg"
                    alt="Hardware Showroom"
                    className="rounded-xl shadow-lg"
                  />
                  <img
                    src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&auto=format&fit=crop&q=60"
                    alt="Wardrobe Display"
                    className="rounded-xl shadow-lg"
                  />
                </div>
                <div className="space-y-4 pt-8">
                  <img
                    src="https://www.blum.com/images/600/400/4053381/localmedia/in/homepage/aventos-top-(1)_3:2.jpg"
                    alt="Kitchen Systems"
                    className="rounded-xl shadow-lg"
                  />
                  <img
                    src="https://www.blum.com/images/600/400/4179638/corporate/media/bilder/produkte/pocketsysteme/blum_revego_me-25342742_3:2.jpg"
                    alt="Sliding Systems"
                    className="rounded-xl shadow-lg"
                  />
                </div>
              </div>
              {/* Stats Card */}
              <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 bg-[#1a1a1a] border border-[#252525] text-white p-6 rounded-xl shadow-xl w-[90%] max-w-md">
                <div className="grid grid-cols-2 gap-4">
                  {stats.slice(0, 2).map((stat, index) => (
                    <div key={index} className="text-center">
                      <p className="text-2xl font-bold gold-text">{stat.value}</p>
                      <p className="text-xs text-white/50">{stat.label}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-24 bg-[#0a0a0a]">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-[#121212] border border-[#1a1a1a] p-10 rounded-xl hover:border-[#d4af37]/20 transition-colors">
              <div className="w-14 h-14 bg-[#d4af37]/10 rounded-xl flex items-center justify-center mb-6">
                <Target className="text-[#d4af37]" size={28} />
              </div>
              <h3 className="text-2xl font-bold text-white mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Our Mission
              </h3>
              <p className="text-white/60">
                To provide architects, designers, contractors, and homeowners with access to the world's finest interior hardware solutions, backed by expert knowledge and exceptional service.
              </p>
            </div>
            
            <div className="bg-[#121212] border border-[#1a1a1a] p-10 rounded-xl hover:border-[#d4af37]/20 transition-colors">
              <div className="w-14 h-14 bg-[#d4af37]/10 rounded-xl flex items-center justify-center mb-6">
                <Eye className="text-[#d4af37]" size={28} />
              </div>
              <h3 className="text-2xl font-bold text-white mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Our Vision
              </h3>
              <p className="text-white/60">
                To be the most trusted and comprehensive interior hardware destination in South India, setting benchmarks in quality, innovation, and customer experience.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-[#121212]">
        <div className="container-custom">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-[#d4af37] text-sm font-semibold tracking-[0.2em] uppercase">Why Choose Us</span>
            <h2 className="text-4xl md:text-5xl font-bold text-white mt-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              The Hyderabad Hardware <span className="gold-text">Difference</span>
            </h2>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: Award,
                title: "Authentic Products",
                description: "100% genuine products from authorized brand partnerships."
              },
              {
                icon: Users,
                title: "Expert Guidance",
                description: "Knowledgeable team to help you choose the right solutions."
              },
              {
                title: "Experience Centres",
                description: "Dedicated Blum and Astronea showrooms for hands-on experience.",
                custom: true
              },
              {
                icon: Check,
                title: "One-Stop Solution",
                description: "Complete range of hardware from multiple premium brands."
              }
            ].map((item, index) => (
              <div key={index} className="text-center p-6 bg-[#1a1a1a] border border-[#252525] rounded-xl hover:border-[#d4af37]/20 transition-colors">
                <div className="w-16 h-16 bg-[#0a0a0a] rounded-xl flex items-center justify-center mx-auto mb-4">
                  {item.custom ? (
                    <div className="flex gap-1">
                      <img src={brandLogos.blum} alt="Blum" className="h-4 w-auto" />
                    </div>
                  ) : (
                    <item.icon className="text-[#d4af37]" size={28} />
                  )}
                </div>
                <h4 className="text-lg font-semibold text-white mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
                  {item.title}
                </h4>
                <p className="text-white/50 text-sm">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Experience Centres Preview */}
      <section className="py-24 bg-[#0a0a0a]">
        <div className="container-custom">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-[#d4af37] text-sm font-semibold tracking-[0.2em] uppercase">Under One Roof</span>
            <h2 className="text-4xl md:text-5xl font-bold text-white mt-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Our <span className="gold-text">Experience Centres</span>
            </h2>
            <p className="text-white/50 mt-4">
              All located in one building, across different floors.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-[#121212] border border-[#1a1a1a] rounded-xl p-8 text-center">
              <div className="w-16 h-16 bg-[#d4af37]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold gold-text">HH</span>
              </div>
              <h3 className="text-xl font-bold text-white mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>Hyderabad Hardware</h3>
              <p className="text-white/40 text-sm mb-4">Ground Floor</p>
              <p className="text-white/60 text-sm">Complete range of furniture fittings, door hardware, and cabinet solutions.</p>
            </div>
            
            <div className="bg-[#121212] border border-[#F7941D]/20 rounded-xl p-8 text-center">
              <div className="mb-4 flex justify-center">
                <img src={brandLogos.blum} alt="Blum" className="h-12 w-auto" />
              </div>
              <p className="text-white/40 text-sm mb-4">First Floor</p>
              <p className="text-white/60 text-sm">Austrian motion technologies, lift systems, and drawer innovations.</p>
              <Link to="/blum">
                <Button className="mt-4 bg-[#F7941D] hover:bg-[#e58a1a] text-white" size="sm">
                  Explore <ArrowRight size={14} className="ml-1" />
                </Button>
              </Link>
            </div>
            
            <div className="bg-[#121212] border border-[#8BC34A]/20 rounded-xl p-8 text-center">
              <div className="mb-4 flex justify-center">
                <img src={brandLogos.astronea} alt="Astronea" className="h-12 w-auto" />
              </div>
              <p className="text-white/40 text-sm mb-4">Second Floor</p>
              <p className="text-white/60 text-sm">Italian wardrobe concepts, door systems, and interior solutions.</p>
              <Link to="/astronea">
                <Button className="mt-4 bg-[#8BC34A] hover:bg-[#7cb342] text-white" size="sm">
                  Explore <ArrowRight size={14} className="ml-1" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-[#121212] border-t border-[#1a1a1a]">
        <div className="container-custom text-center">
          <h2 className="text-3xl font-bold text-white mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Visit Our <span className="gold-text">Showroom</span> Today
          </h2>
          <p className="text-white/50 mb-8 max-w-xl mx-auto">
            Experience our products firsthand and let our experts help you find the perfect solutions for your project.
          </p>
          <Link to="/contact">
            <Button size="lg" className="btn-gold-gradient font-semibold px-8 border-0">
              Get Directions <ArrowRight size={18} className="ml-2" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;
