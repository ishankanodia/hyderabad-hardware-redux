import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Clock, ArrowRight } from 'lucide-react';
import { companyInfo, experienceCentres, brandLogos } from '../data/mock';

const Footer = () => {
  const quickLinks = [
    { name: 'About Us', path: '/about' },
    { name: 'Products & Solutions', path: '/products' },
    { name: 'Brands We Work With', path: '/brands' },
    { name: 'Our Showrooms', path: '/showrooms' },
    { name: 'Contact Us', path: '/contact' },
  ];

  const experienceLinks = [
    { name: 'Blum Experience Centre', path: '/blum' },
    { name: 'Astronea Experience Centre', path: '/astronea' },
  ];

  return (
    <footer className="bg-[#0a0a0a] text-white border-t border-[#1a1a1a]">
      {/* Main Footer */}
      <div className="container-custom py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand Column */}
          <div className="space-y-6">
            <Link to="/" className="inline-block">
              <div className="flex items-center gap-3">
                <span className="text-3xl font-bold" style={{ 
                  fontFamily: 'Poppins, sans-serif',
                  background: 'linear-gradient(135deg, #d4af37, #e5c158)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent'
                }}>HH</span>
                <div>
                  <div className="text-lg font-bold text-[#d4af37]" style={{ fontFamily: 'Poppins, sans-serif' }}>
                    HYDERABAD
                  </div>
                  <div className="text-xs tracking-[0.2em] text-white/50">HARDWARE</div>
                </div>
              </div>
            </Link>
            <p className="text-white/50 text-sm leading-relaxed">
              Your trusted partner for premium interior solutions. Offering world-class architectural hardware, kitchen systems, wardrobe systems, and furniture fittings.
            </p>
            {/* Experience Centre Logos */}
            <div className="flex gap-4 pt-2">
              <Link to="/blum" className="opacity-70 hover:opacity-100 transition-opacity">
                <img 
                  src={brandLogos.blum} 
                  alt="Blum Experience Centre" 
                  className="h-8 w-auto object-contain"
                />
              </Link>
              <Link to="/astronea" className="opacity-70 hover:opacity-100 transition-opacity">
                <img 
                  src={brandLogos.astronea} 
                  alt="Astronea Experience Centre" 
                  className="h-8 w-auto object-contain"
                />
              </Link>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-6">
            <h4 className="text-base font-semibold text-white" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Quick Links
            </h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-white/50 hover:text-[#d4af37] transition-colors flex items-center gap-2 group text-sm"
                  >
                    <ArrowRight size={12} className="opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all text-[#d4af37]" />
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Experience Centres */}
          <div className="space-y-6">
            <h4 className="text-base font-semibold text-white" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Experience Centres
            </h4>
            <ul className="space-y-3">
              {experienceLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-white/50 hover:text-[#d4af37] transition-colors flex items-center gap-2 group text-sm"
                  >
                    <ArrowRight size={12} className="opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all text-[#d4af37]" />
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
            <div className="pt-4 border-t border-[#1a1a1a]">
              <h5 className="text-sm font-medium text-white/70 mb-2">Business Hours</h5>
              <div className="flex items-start gap-2 text-white/50 text-sm">
                <Clock size={14} className="mt-0.5 shrink-0 text-[#d4af37]" />
                <div>
                  <p>Mon - Sat: 10:00 AM - 8:00 PM</p>
                  <p>Sunday: By Appointment</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-6">
            <h4 className="text-base font-semibold text-white" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Contact Us
            </h4>
            <div className="space-y-4">
              <a href={`tel:${companyInfo.phones[0]}`} className="flex items-start gap-3 text-white/50 hover:text-[#d4af37] transition-colors text-sm">
                <Phone size={16} className="mt-0.5 shrink-0 text-[#d4af37]" />
                <div>
                  <p>{companyInfo.phones[0]}</p>
                  <p>{companyInfo.phones[1]}</p>
                </div>
              </a>
              <a href={`mailto:${companyInfo.emails[0]}`} className="flex items-start gap-3 text-white/50 hover:text-[#d4af37] transition-colors text-sm">
                <Mail size={16} className="mt-0.5 shrink-0 text-[#d4af37]" />
                <div>
                  <p>{companyInfo.emails[0]}</p>
                  <p>{companyInfo.emails[1]}</p>
                </div>
              </a>
              <div className="flex items-start gap-3 text-white/50 text-sm">
                <MapPin size={16} className="mt-0.5 shrink-0 text-[#d4af37]" />
                <div>
                  <p>{companyInfo.address.line1}</p>
                  <p>{companyInfo.address.line2}</p>
                  <p>{companyInfo.address.city}, {companyInfo.address.state}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-[#1a1a1a]">
        <div className="container-custom py-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-white/30 text-sm">
            © {new Date().getFullYear()} Hyderabad Hardware. All rights reserved.
          </p>
          <div className="flex items-center gap-6 text-sm text-white/30">
            <Link to="/" className="hover:text-white/50 transition-colors">Privacy Policy</Link>
            <Link to="/" className="hover:text-white/50 transition-colors">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
