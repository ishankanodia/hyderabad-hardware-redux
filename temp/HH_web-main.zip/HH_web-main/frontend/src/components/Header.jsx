import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Phone, Mail, MapPin, Menu } from 'lucide-react';
import { companyInfo, brandLogos } from '../data/mock';
import { Button } from './ui/button';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "./ui/sheet";

const navLinks = [
  { name: 'Home', path: '/' },
  { name: 'About', path: '/about' },
  { name: 'Products', path: '/products' },
  { name: 'Brands', path: '/brands' },
  { name: 'Blum', path: '/blum' },
  { name: 'Astronea', path: '/astronea' },
  { name: 'Showrooms', path: '/showrooms' },
  { name: 'Contact', path: '/contact' },
];

const Header = () => {
  const location = useLocation();
  const [isOpen, setIsOpen] = React.useState(false);
  const [scrolled, setScrolled] = React.useState(false);

  React.useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed w-full z-50 transition-all duration-500 ${
      scrolled 
        ? 'bg-[#0a0a0a]/95 backdrop-blur-xl shadow-2xl shadow-black/50' 
        : 'bg-gradient-to-b from-[#0a0a0a] to-transparent'
    }`}>
      {/* Top Bar */}
      <div className="hidden lg:block bg-[#0a0a0a] border-b border-[#1a1a1a] text-white/70 text-sm py-2">
        <div className="container-custom flex justify-between items-center">
          <div className="flex items-center gap-6">
            <a href={`tel:${companyInfo.phones[0]}`} className="flex items-center gap-2 hover:text-[#d4af37] transition-colors">
              <Phone size={13} className="text-[#d4af37]" />
              <span>{companyInfo.phones[0]}</span>
            </a>
            <a href={`mailto:${companyInfo.emails[0]}`} className="flex items-center gap-2 hover:text-[#d4af37] transition-colors">
              <Mail size={13} className="text-[#d4af37]" />
              <span>{companyInfo.emails[0]}</span>
            </a>
          </div>
          <div className="flex items-center gap-2 text-white/50">
            <MapPin size={13} className="text-[#d4af37]" />
            <span>Srinagar Colony, Hyderabad</span>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <nav className="container-custom py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3">
            <div className="flex items-center gap-3">
              {/* HH Monogram */}
              <div className="relative">
                <div className="w-12 h-12 flex items-center justify-center">
                  <span className="text-2xl font-bold tracking-tight" style={{ 
                    fontFamily: 'Poppins, sans-serif',
                    background: 'linear-gradient(135deg, #d4af37, #e5c158, #d4af37)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent'
                  }}>
                    HH
                  </span>
                </div>
              </div>
              {/* Brand Name */}
              <div className="hidden sm:block">
                <div className="text-lg font-bold tracking-wide" style={{ 
                  fontFamily: 'Poppins, sans-serif',
                  background: 'linear-gradient(135deg, #d4af37, #e5c158)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent'
                }}>
                  HYDERABAD
                </div>
                <div className="text-xs tracking-[0.3em] text-white/60 -mt-0.5">
                  HARDWARE
                </div>
              </div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`px-4 py-2 text-sm font-medium transition-all duration-300 relative group ${
                  location.pathname === link.path
                    ? 'text-[#d4af37]'
                    : 'text-white/70 hover:text-white'
                }`}
              >
                {link.name}
                <span className={`absolute bottom-0 left-1/2 -translate-x-1/2 h-0.5 bg-gradient-to-r from-[#d4af37] to-[#e5c158] transition-all duration-300 ${
                  location.pathname === link.path ? 'w-1/2' : 'w-0 group-hover:w-1/2'
                }`} />
              </Link>
            ))}
          </div>

          {/* CTA Button */}
          <div className="hidden lg:flex items-center gap-4">
            <a href={`tel:${companyInfo.phones[0]}`}>
              <Button className="btn-gold-gradient font-semibold px-6 border-0">
                <Phone size={16} className="mr-2" />
                Call Now
              </Button>
            </a>
          </div>

          {/* Mobile Menu */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild className="lg:hidden">
              <Button variant="ghost" size="icon" className="text-white hover:text-[#d4af37] hover:bg-white/5">
                <Menu size={24} />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] bg-[#0a0a0a] border-[#1a1a1a]">
              <div className="flex flex-col h-full pt-8">
                {/* Mobile Logo */}
                <div className="px-4 mb-8">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl font-bold" style={{ 
                      background: 'linear-gradient(135deg, #d4af37, #e5c158)',
                      WebkitBackgroundClip: 'text',
                      WebkitTextFillColor: 'transparent'
                    }}>HH</span>
                    <div>
                      <div className="text-sm font-bold text-[#d4af37]">HYDERABAD</div>
                      <div className="text-xs text-white/50 tracking-wider">HARDWARE</div>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col gap-1">
                  {navLinks.map((link) => (
                    <Link
                      key={link.path}
                      to={link.path}
                      onClick={() => setIsOpen(false)}
                      className={`px-4 py-3 text-base font-medium transition-all border-l-2 ${
                        location.pathname === link.path
                          ? 'text-[#d4af37] bg-[#d4af37]/5 border-[#d4af37]'
                          : 'text-white/70 hover:text-white hover:bg-white/5 border-transparent hover:border-[#d4af37]/50'
                      }`}
                    >
                      {link.name}
                    </Link>
                  ))}
                </div>
                <div className="mt-auto pb-8 px-4 space-y-4 border-t border-[#1a1a1a] pt-6">
                  <a href={`tel:${companyInfo.phones[0]}`} className="flex items-center gap-3 text-white/70 hover:text-[#d4af37] transition-colors">
                    <Phone size={18} className="text-[#d4af37]" />
                    <span>{companyInfo.phones[0]}</span>
                  </a>
                  <a href={`mailto:${companyInfo.emails[0]}`} className="flex items-center gap-3 text-white/70 hover:text-[#d4af37] transition-colors">
                    <Mail size={18} className="text-[#d4af37]" />
                    <span className="text-sm">{companyInfo.emails[0]}</span>
                  </a>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </nav>
    </header>
  );
};

export default Header;
